'use strict';
// File versions are stored in Postgres (blobs.bytea, de-duplicated by SHA-256) so the portal works on serverless hosts.
const path = require('path');
const crypto = require('crypto');
const { q } = require('./db');

const MIME = {
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.pdf': 'application/pdf', '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.txt': 'text/plain', '.csv': 'text/csv',
};
const ALLOWED = new Set(Object.keys(MIME));
const mimeFor = (name) => MIME[path.extname(name).toLowerCase()] || 'application/octet-stream';

async function saveVersion(docId, buf, fileName, note, userId) {
  const sha = crypto.createHash('sha256').update(buf).digest('hex');
  await q.run('INSERT OR IGNORE INTO blobs (sha256, data) VALUES (?, ?)', sha, buf);
  const v = ((await q.get('SELECT MAX(version) v FROM doc_versions WHERE doc_id=?', docId)).v || 0) + 1;
  await q.run('INSERT INTO doc_versions (doc_id, version, file_name, stored_name, mime, size, sha256, change_note, created_by) VALUES (?,?,?,?,?,?,?,?,?)',
    docId, v, fileName, sha + path.extname(fileName).toLowerCase(), mimeFor(fileName), buf.length, sha, note || null, userId || null);
  await q.run("UPDATE documents SET updated_at=datetime('now') WHERE id=?", docId);
  return v;
}
const latest = (docId) => q.get('SELECT * FROM doc_versions WHERE doc_id=? ORDER BY version DESC LIMIT 1', docId);
async function readBlob(v) { const r = await q.get('SELECT data FROM blobs WHERE sha256=?', v.sha256); return r ? Buffer.from(r.data) : null; }

module.exports = { saveVersion, latest, readBlob, mimeFor, ALLOWED };
