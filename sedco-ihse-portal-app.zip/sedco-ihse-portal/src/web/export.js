'use strict';
// Structured country ZIP: <Country>/00_Index + <NN_Clause>/<subclause>/{01_Procedures_Policies,02_Blank_Forms,03_Live_Registers,04_Completed_Records,05_Original_Sources}
const archiver = require('archiver');
const fs = require('fs');
const { q } = require('../db');
const { latest, readBlob } = require('../store');
const X = require('../gen/xlsx');
const { CLAUSES } = require('../content/nodes');

const FOLDER = { procedure: '01_Procedures_Policies', policy: '01_Procedures_Policies', instruction: '01_Procedures_Policies', form: '02_Blank_Forms', register: '03_Live_Registers', record: '04_Completed_Records', source: '05_Original_Sources' };
const CNAME = { EG: 'Egypt', SA: 'KSA' };
const safe = (s) => String(s).replace(/[\\/:*?"<>|]+/g, '_').replace(/\s+/g, '_').slice(0, 120);
const urlFile = (url) => `[InternetShortcut]\r\nURL=${url}\r\n`;

async function indexWorkbooks(c) {
  const docs = (await q.all(`SELECT d.*, (SELECT group_concat(node_code, ', ') FROM doc_links WHERE doc_id=d.id) nodes, (SELECT MAX(version) FROM doc_versions WHERE doc_id=d.id) ver,
    s.location, s.url FROM documents d LEFT JOIN sources s ON s.id=d.source_id WHERE d.country=? ORDER BY d.doc_type, d.code`, c));
  const docIndex = await X.tableExport('Document & record index', 'فهرس الوثائق والسجلات', c, `IHSE-${c}-IDX-DOC`, [
    { key: 'code', en: 'Code', ar: 'الكود', width: 22 }, { key: 'title_en', en: 'Title', ar: 'العنوان', width: 44 }, { key: 'doc_type', en: 'Type', ar: 'النوع', width: 12 },
    { key: 'status', en: 'Status', ar: 'الحالة', width: 12 }, { key: 'origin', en: 'Origin', ar: 'الأصل', width: 11 }, { key: 'ver', en: 'Latest version', ar: 'آخر إصدار', width: 9 },
    { key: 'approved_version', en: 'Approved version', ar: 'الإصدار المعتمد', width: 9 }, { key: 'nodes', en: 'Subclauses', ar: 'البنود', width: 18 },
    { key: 'record_date', en: 'Record / file date', ar: 'التاريخ', width: 12 }, { key: 'location', en: 'Original location', ar: 'الموقع الأصلي', width: 60 }],
    docs.map(d => ({ ...d, status: d.status === 'review' && d.origin === 'source' ? 'approval not confirmed' : d.status })),
    ['Lists every document and record registered for this country, with status and subclause links.', 'Origin: generated (portal), source (company file linked by location), uploaded (stored in portal).', 'Records with origin "source" are listed by location; binaries remain in SharePoint.']);
  const matrix = await matrixWorkbook(c);
  const conf = await confirmationsWorkbook(c);
  const acts = await X.tableExport('Action register', 'سجل الإجراءات', c, `IHSE-${c}-IDX-ACT`, [
    { key: 'id', en: 'ID', ar: 'الرقم', width: 6 }, { key: 'source', en: 'Source', ar: 'المصدر', width: 16 }, { key: 'node_code', en: 'Subclause', ar: 'البند', width: 9 },
    { key: 'description', en: 'Action', ar: 'الإجراء', width: 60 }, { key: 'owner', en: 'Owner', ar: 'المسؤول', width: 18 }, { key: 'due_date', en: 'Due', ar: 'الموعد', width: 12 },
    { key: 'status', en: 'Status', ar: 'الحالة', width: 12 }, { key: 'effectiveness', en: 'Effectiveness', ar: 'الفعالية', width: 24 }, { key: 'origin', en: 'Origin', ar: 'الأصل', width: 12 }],
    (await q.all('SELECT * FROM actions WHERE country=? ORDER BY id', c)).map(a => ({ ...a, due_date: a.due_date || 'CONFIRMATION REQUIRED: due date not set' })),
    ['Origin "portal-review" = finding raised while building the portal from source files; owner shown is a role.']);
  const src = await X.tableExport('Source inventory', 'جرد المصادر', c, `IHSE-${c}-IDX-SRC`, [
    { key: 'id', en: 'Source ID', ar: 'المعرف', width: 16 }, { key: 'filename', en: 'File / folder', ar: 'الملف', width: 40 }, { key: 'kind', en: 'Kind', ar: 'النوع', width: 11 },
    { key: 'node_code', en: 'Subclause', ar: 'البند', width: 9 }, { key: 'modified', en: 'Date', ar: 'التاريخ', width: 11 }, { key: 'size', en: 'Bytes', ar: 'الحجم', width: 12 },
    { key: 'access', en: 'Access', ar: 'الوصول', width: 10 }, { key: 'intended_use', en: 'Intended use', ar: 'الاستخدام', width: 40 }, { key: 'note', en: 'Note', ar: 'ملاحظة', width: 50 }, { key: 'location', en: 'Location', ar: 'الموقع', width: 70 }],
    (await q.all("SELECT * FROM sources WHERE country IN (?, 'GL') ORDER BY id", c)),
    ['access: read = content opened and used; listed = filename/metadata only; empty = empty folder; excluded = out of scope by user instruction.']);
  return { docIndex, matrix, conf, acts, src };
}

async function matrixWorkbook(c) {
  const rows = [];
  const status = Object.fromEntries((await q.all('SELECT node_code, status, impl FROM node_country WHERE country=?', c)).map(r => [r.node_code, r]));
  for (const r of (await q.all('SELECT * FROM requirements ORDER BY sort'))) {
    const nodes = (await q.all('SELECT n.* FROM nodes n JOIN node_reqs nr ON nr.node_code=n.code WHERE nr.req_id=?', r.id));
    if (r.applicability === 'R') { rows.push({ std: r.standard === 'ISO45001' ? 'ISO 45001:2018+A1:2024' : 'ISO 14001:2026', ref: r.ref, title: r.title, para: r.paraphrase, response: 'Reference clause — no auditable requirement; used as portal glossary/scope reference', status: 'n/a (reference)' }); continue; }
    for (const n of nodes) {
      const docs = (await q.all("SELECT d.code, d.doc_type FROM documents d JOIN doc_links l ON l.doc_id=d.id WHERE l.node_code=? AND d.country=?", n.code, c));
      const gaps = (await q.all("SELECT id FROM confirmations WHERE node_code=? AND country=? AND status<>'resolved'", n.code, c)).map(g => g.id);
      const st = status[n.code] || {};
      rows.push({ std: r.standard === 'ISO45001' ? 'ISO 45001:2018+A1:2024' : 'ISO 14001:2026', ref: r.ref, title: r.title, para: r.paraphrase,
        node: `${n.code} ${n.title_en}`, response: n.method, site: c === 'EG' ? 'Egypt plant' : 'KSA Riyadh plant', role: JSON.parse(n.roles || '[]')[0] || '',
        procs: docs.filter(d => ['procedure', 'policy', 'instruction'].includes(d.doc_type)).map(d => d.code).join(', '),
        forms: docs.filter(d => d.doc_type === 'form').map(d => d.code).join(', '), registers: docs.filter(d => d.doc_type === 'register').map(d => d.code).join(', '),
        records: docs.filter(d => d.doc_type === 'record').map(d => d.code).join(', '), status: st.status,
        gaps: gaps.length ? `CONFIRMATION REQUIRED: ${gaps.join(', ')}` : '' });
    }
  }
  return X.tableExport('Clause coverage matrix', 'مصفوفة تغطية البنود', c, `IHSE-${c}-IDX-MTX`, [
    { key: 'std', en: 'Standard & verified edition', ar: 'المعيار والإصدار', width: 20 }, { key: 'ref', en: 'Clause', ar: 'البند', width: 8 }, { key: 'title', en: 'Title', ar: 'العنوان', width: 28 },
    { key: 'para', en: 'Requirement (paraphrase)', ar: 'المتطلب (صياغة)', width: 50 }, { key: 'node', en: 'Integrated subclause page', ar: 'صفحة البند المتكامل', width: 28 },
    { key: 'response', en: 'Integrated system response', ar: 'استجابة النظام', width: 50 }, { key: 'site', en: 'Country / site', ar: 'الموقع', width: 14 }, { key: 'role', en: 'Responsible role', ar: 'الدور المسؤول', width: 24 },
    { key: 'procs', en: 'Procedures', ar: 'الإجراءات', width: 26 }, { key: 'forms', en: 'Forms', ar: 'النماذج', width: 22 }, { key: 'registers', en: 'Registers', ar: 'السجلات', width: 22 },
    { key: 'records', en: 'Evidence (records)', ar: 'الأدلة', width: 26 }, { key: 'status', en: 'Implementation status', ar: 'حالة التطبيق', width: 18 }, { key: 'gaps', en: 'Outstanding gaps', ar: 'الفجوات', width: 28 }],
    rows, ['One row per standard subclause per integrated page. Clauses 1–3 are reference rows.', 'ISO 45001 numbering follows the published 2018 edition (see CR-GL-0001); ISO 14001 numbering verified against the licensed 2026 copy.', 'Requirement text is paraphrased, not reproduced.']);
}

async function confirmationsWorkbook(c) {
  const rows = (await q.all(`SELECT * FROM confirmations WHERE ${c === 'ALL' ? '1=1' : "country IN (?, 'GL')"} ORDER BY country, priority, id`, ...(c === 'ALL' ? [] : [c])));
  return X.tableExport('Missing information & confirmation register', 'سجل المعلومات الناقصة والتأكيدات', c === 'ALL' ? 'GL' : c, `IHSE-${c}-IDX-CNF`, [
    { key: 'id', en: 'ID', ar: 'المعرف', width: 13 }, { key: 'country', en: 'Country', ar: 'الدولة', width: 8 }, { key: 'node_code', en: 'Clause / page', ar: 'البند', width: 9 },
    { key: 'missing', en: 'Exact missing information', ar: 'المعلومة الناقصة', width: 55 }, { key: 'why', en: 'Why needed', ar: 'سبب الحاجة', width: 40 }, { key: 'proposed', en: 'Proposed draft', ar: 'المقترح', width: 36 },
    { key: 'source_person', en: 'Required source / person', ar: 'المصدر / الشخص', width: 24 }, { key: 'owner', en: 'Owner', ar: 'المسؤول', width: 20 }, { key: 'priority', en: 'Priority', ar: 'الأولوية', width: 8 },
    { key: 'status', en: 'Status', ar: 'الحالة', width: 10 }, { key: 'link', en: 'Link to affected item', ar: 'الرابط', width: 36 }],
    rows.map(r => ({ ...r, missing: r.status === 'resolved' ? r.missing : 'CONFIRMATION REQUIRED: ' + r.missing, link: r.node_code ? `/c/${r.country}/sub/${r.node_code}` : '/confirmations' })),
    ['Every unknown, unverified or conflicting item found while building the system. Yellow = open.', 'Resolve in the portal (Confirmation register → Resolve) so the dashboard updates.']);
}

async function countryZip(c, res) {
  const root = CNAME[c];
  const zip = archiver('zip', { zlib: { level: 6 } });
  zip.pipe(res);
  const idx = await indexWorkbooks(c);
  zip.append(Buffer.from(idx.docIndex), { name: `${root}/00_Index/Document_and_Record_Index.xlsx` });
  zip.append(Buffer.from(idx.matrix), { name: `${root}/00_Index/Clause_Coverage_Matrix.xlsx` });
  zip.append(Buffer.from(idx.conf), { name: `${root}/00_Index/Missing_Information_and_Confirmation_Register.xlsx` });
  zip.append(Buffer.from(idx.acts), { name: `${root}/00_Index/Action_Register.xlsx` });
  zip.append(Buffer.from(idx.src), { name: `${root}/00_Index/Source_Inventory.xlsx` });
  const listing = [];
  for (const n of (await q.all('SELECT * FROM nodes ORDER BY sort'))) {
    const cl = CLAUSES.find(x => x.n === n.clause);
    const base = `${root}/${cl.folder}/${n.folder}`;
    zip.append('', { name: base + '/' });
    const docs = (await q.all('SELECT d.*, s.url FROM documents d JOIN doc_links l ON l.doc_id=d.id LEFT JOIN sources s ON s.id=d.source_id WHERE l.node_code=? AND d.country=? ORDER BY d.code', n.code, c));
    for (const d of docs) {
      const folder = `${base}/${FOLDER[d.doc_type] || '05_Original_Sources'}`;
      const v = await latest(d.id);
      const blob = v ? await readBlob(v) : null;
      if (blob) {
        const name = `${folder}/${safe(d.code)}${d.status === 'approved' ? '' : '_' + d.status.toUpperCase()}${v.file_name.slice(v.file_name.lastIndexOf('.'))}`;
        zip.append(blob, { name }); listing.push([name, d.code, d.title_en, d.doc_type, d.status, 'file']);
      } else if (d.url) {
        const name = `${folder}/${safe(d.code + ' ' + (d.description || d.title_en).split(' — ')[0])}.url`;
        zip.append(urlFile(d.url), { name }); listing.push([name, d.code, d.title_en, d.doc_type, d.status, 'link to SharePoint original']);
      }
    }
  }
  zip.append('﻿path,code,title,type,status,content\r\n' + listing.map(r => r.map(x => `"${String(x).replace(/"/g, '""')}"`).join(',')).join('\r\n'), { name: `${root}/00_Index/package_file_list.csv` });
  zip.append(`${root} — SEDCO Integrated HSE package\r\nGenerated: ${new Date().toISOString()}\r\n\r\nFile names ending _DRAFT / _REVIEW are not approved. "_REVIEW" on company source links means approval in the original system was not confirmed.\r\n.url files are shortcuts to the original SharePoint files (company access required).\r\nSee 00_Index for the document index, clause coverage matrix and confirmation register.\r\n`, { name: `${root}/README.txt` });
  await zip.finalize();
}

module.exports = { countryZip, indexWorkbooks, matrixWorkbook, confirmationsWorkbook };
