'use strict';
const T = {
  en: {
    app: 'SEDCO Integrated HSE Portal', company: 'Elsewedy Cable Accessories', dashboard: 'Dashboard', both: 'Both countries', EG: 'Egypt', SA: 'KSA — Riyadh', GL: 'Global',
    clauses: 'Clauses', documents: 'Documents', records: 'Completed records', actions: 'Actions', confirmations: 'Confirmation register', matrix: 'Clause coverage matrix',
    sources: 'Source inventory', exports: 'Exports', admin: 'Administration', users: 'Users', audit: 'Audit log', search: 'Search', logout: 'Sign out', login: 'Sign in',
    username: 'Username', password: 'Password', back: 'Back', workspace: 'Workspace', language: 'العربية', clause: 'Clause', subclause: 'Subclause',
    req_summary: '1. Requirement summary', how: '2. How SEDCO implements it', resp: '3. Responsibilities and process steps', procs: '4. Procedures and supporting documents',
    forms: '5. Blank forms', evidence: '6. Completed records and evidence', gaps: '7. Gaps and required confirmations', auditchk: '8. Relevant audit checks',
    status: 'Status', owner: 'Owner', type: 'Type', code: 'Code', title: 'Title', date: 'Date', country: 'Country', standard: 'Standard', all: 'All', filter: 'Filter',
    download: 'Download', preview: 'Preview', versions: 'Revision history', upload: 'Upload', save: 'Save', new_doc: 'Register document', new_action: 'New action',
    draft: 'Draft — pending approval', review: 'In review / approval not confirmed', approved: 'Approved', obsolete: 'Obsolete', priority: 'Priority', due: 'Due',
    'implemented-evidence': 'Implemented — evidence located', 'confirmation-required': 'Confirmation required', 'evidence-missing': 'Evidence missing', na: 'Not applicable',
    procedure: 'Procedure', policy: 'Policy', form: 'Blank form', register: 'Live register', record: 'Completed record', source: 'Original source', instruction: 'Instruction',
    open: 'Open', in_progress: 'In progress', done: 'Done', verified: 'Verified effective', cancelled: 'Cancelled', resolved: 'Resolved', export_zip: 'Download country package (ZIP)', account: 'Account', change_pw: 'Change password',
  },
  ar: {
    app: 'بوابة النظام المتكامل للسلامة والصحة المهنية والبيئة — سيدكو', company: 'السويدي لإكسسوارات الكابلات', dashboard: 'لوحة المتابعة', both: 'الدولتان', EG: 'مصر', SA: 'السعودية — الرياض', GL: 'عام',
    clauses: 'البنود', documents: 'الوثائق', records: 'السجلات المكتملة', actions: 'الإجراءات', confirmations: 'سجل التأكيدات', matrix: 'مصفوفة تغطية البنود',
    sources: 'جرد المصادر', exports: 'التصدير', admin: 'الإدارة', users: 'المستخدمون', audit: 'سجل التدقيق', search: 'بحث', logout: 'تسجيل الخروج', login: 'تسجيل الدخول',
    username: 'اسم المستخدم', password: 'كلمة المرور', back: 'رجوع', workspace: 'مساحة العمل', language: 'English', clause: 'البند', subclause: 'البند الفرعي',
    req_summary: '١. ملخص المتطلب', how: '٢. طريقة التطبيق في سيدكو', resp: '٣. المسؤوليات وخطوات العملية', procs: '٤. الإجراءات والوثائق الداعمة',
    forms: '٥. النماذج الفارغة', evidence: '٦. السجلات المكتملة والأدلة', gaps: '٧. الفجوات والتأكيدات المطلوبة', auditchk: '٨. أسئلة التدقيق',
    status: 'الحالة', owner: 'المسؤول', type: 'النوع', code: 'الكود', title: 'العنوان', date: 'التاريخ', country: 'الدولة', standard: 'المعيار', all: 'الكل', filter: 'تصفية',
    download: 'تنزيل', preview: 'معاينة', versions: 'سجل الإصدارات', upload: 'رفع', save: 'حفظ', new_doc: 'تسجيل وثيقة', new_action: 'إجراء جديد',
    draft: 'مسودة — بانتظار الاعتماد', review: 'قيد المراجعة / الاعتماد غير مؤكد', approved: 'معتمد', obsolete: 'ملغى', priority: 'الأولوية', due: 'الموعد',
    'implemented-evidence': 'مطبق — توجد أدلة', 'confirmation-required': 'يلزم التأكيد', 'evidence-missing': 'الدليل مفقود', na: 'غير منطبق',
    procedure: 'إجراء', policy: 'سياسة', form: 'نموذج فارغ', register: 'سجل حي', record: 'سجل مكتمل', source: 'مصدر أصلي', instruction: 'تعليمات',
    open: 'مفتوح', in_progress: 'قيد التنفيذ', done: 'منجز', verified: 'تم التحقق من الفعالية', cancelled: 'ملغى', resolved: 'تم الحل', export_zip: 'تنزيل حزمة الدولة (ZIP)', account: 'الحساب', change_pw: 'تغيير كلمة المرور',
  },
};
const t = (lang) => (k) => (T[lang] && T[lang][k]) || T.en[k] || k;
module.exports = { t, T };
