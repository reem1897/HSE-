'use strict';
// All dashboard numbers are computed from stored data. Each metric returns {n, d, def} so the page can show the denominator.
const { q } = require('../db');

const today = () => new Date().toISOString().slice(0, 10);
const plus = (days) => new Date(Date.now() + days * 864e5).toISOString().slice(0, 10);

async function reqCoverage(c) {
  const reqs = (await q.all("SELECT r.id, nr.node_code FROM requirements r LEFT JOIN node_reqs nr ON nr.req_id=r.id WHERE r.applicability='A'"));
  const ids = [...new Set(reqs.map(r => r.id))];
  const nodeOf = {}; reqs.forEach(r => { if (r.node_code) (nodeOf[r.id] = nodeOf[r.id] || []).push(r.node_code); });
  const nodeDocs = {}; (await q.all(`SELECT l.node_code, d.doc_type, d.status, d.origin FROM doc_links l JOIN documents d ON d.id=l.doc_id WHERE d.country=?`, c))
    .forEach(x => (nodeDocs[x.node_code] = nodeDocs[x.node_code] || []).push(x));
  const nodeStatus = {}; (await q.all('SELECT node_code, status FROM node_country WHERE country=?', c)).forEach(x => nodeStatus[x.node_code] = x.status);
  let mapped = 0, documented = 0, approvedDoc = 0, evidence = 0;
  ids.forEach(id => {
    const ns = nodeOf[id] || []; if (!ns.length) return; mapped++;
    const docs = ns.flatMap(n => nodeDocs[n] || []);
    if (docs.some(d => ['procedure', 'policy', 'register', 'instruction'].includes(d.doc_type) && d.status !== 'obsolete' && (d.origin !== 'generated' || d.status === 'approved'))) documented++;
    if (docs.some(d => ['procedure', 'policy'].includes(d.doc_type) && d.status === 'approved')) approvedDoc++;
    if (ns.some(n => nodeStatus[n] === 'implemented-evidence') && docs.some(d => d.doc_type === 'record' && d.status !== 'obsolete')) evidence++;
  });
  const d = ids.length;
  return {
    mapped: { n: mapped, d, def: 'Applicable subclauses of both standards (clauses 4–10, nested) that have an integrated subclause page.' },
    documented: { n: documented, d, def: 'Applicable subclauses whose page links at least one company procedure, policy, instruction or register (from sources or uploaded), or an approved portal document. Portal-generated drafts do not count.' },
    approvedDoc: { n: approvedDoc, d, def: 'Applicable subclauses with at least one APPROVED procedure/policy in this portal. Company documents whose approval is not confirmed do not count.' },
    evidence: { n: evidence, d, def: 'Applicable subclauses whose page status is "Implemented — evidence located" AND that link at least one completed record. Measures evidence located, not verified effectiveness.' },
  };
}

async function countryMetrics(c) {
  const T = today();
  const docs = (await q.all("SELECT status, COUNT(*) n FROM documents WHERE country=? AND doc_type<>'record' AND doc_type<>'source' GROUP BY status", c));
  const docStatus = Object.fromEntries(docs.map(r => [r.status, r.n]));
  const conf = (await q.all("SELECT priority, COUNT(*) n FROM confirmations WHERE country=? AND status<>'resolved' GROUP BY priority", c));
  const confP = Object.fromEntries(conf.map(r => [r.priority, r.n]));
  const actionsOpen = (await q.get("SELECT COUNT(*) n FROM actions WHERE country=? AND status IN ('open','in_progress')", c)).n;
  const overdue = (await q.get("SELECT COUNT(*) n FROM actions WHERE country=? AND status IN ('open','in_progress') AND due_date IS NOT NULL AND due_date < ?", c, T)).n;
  const noDue = (await q.get("SELECT COUNT(*) n FROM actions WHERE country=? AND status IN ('open','in_progress') AND due_date IS NULL", c)).n;
  const auditAll = (await q.get("SELECT COUNT(*) n FROM actions WHERE country=? AND source IN ('Internal audit','External audit')", c)).n;
  const auditClosed = (await q.get("SELECT COUNT(*) n FROM actions WHERE country=? AND source IN ('Internal audit','External audit') AND status IN ('done','verified')", c)).n;
  const nodeStatus = Object.fromEntries((await q.all('SELECT status, COUNT(*) n FROM node_country WHERE country=? GROUP BY status', c)).map(r => [r.status, r.n]));
  const nodesTotal = (await q.get('SELECT COUNT(*) n FROM node_country WHERE country=?', c)).n;
  const upcoming = [
    ...(await q.all("SELECT 'Action' kind, id, description label, due_date d, node_code FROM actions WHERE country=? AND status IN ('open','in_progress') AND due_date BETWEEN ? AND ? ORDER BY due_date", c, T, plus(60))),
    ...(await q.all("SELECT 'Document review' kind, id, code||' '||title_en label, review_due d, NULL node_code FROM documents WHERE country=? AND review_due BETWEEN ? AND ? ORDER BY review_due", c, T, plus(60))),
  ];
  const records = (await q.get("SELECT COUNT(*) n FROM documents WHERE country=? AND doc_type='record'", c)).n;
  const uploadedRecords = (await q.get("SELECT COUNT(*) n FROM documents WHERE country=? AND doc_type='record' AND origin='uploaded'", c)).n;
  return { cov: await reqCoverage(c), docStatus, confP, confOpen: (confP.H || 0) + (confP.M || 0) + (confP.L || 0), actionsOpen, overdue, noDue, auditAll, auditClosed, nodeStatus, nodesTotal, upcoming, records, uploadedRecords };
}

function readiness(m) {
  const reasons = [];
  if (m.confP.H) reasons.push(`${m.confP.H} high-priority confirmation item(s) open`);
  if (m.nodeStatus['evidence-missing']) reasons.push(`${m.nodeStatus['evidence-missing']} subclause page(s) with evidence missing`);
  if (m.cov.approvedDoc.n < m.cov.approvedDoc.d) reasons.push(`${m.cov.approvedDoc.d - m.cov.approvedDoc.n} of ${m.cov.approvedDoc.d} applicable subclauses without an approved procedure in the portal`);
  if (m.overdue) reasons.push(`${m.overdue} overdue action(s)`);
  return reasons.length ? { ready: false, text: 'Not audit-ready', reasons } : { ready: true, text: 'No blocking gaps recorded — confirm by internal audit', reasons: [] };
}

module.exports = { countryMetrics, readiness, reqCoverage };
