'use strict';
// Builds the database from the content files and generates version-1 documents. Idempotent: refuses to reseed a populated DB
// unless --force is given (which wipes content tables but keeps users and the audit log).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { q, tx, migrate, log, DATA_DIR } = require('./db');
const { requirements } = require('./content/standards');
const { CLAUSES, nodes } = require('./content/nodes');
const { sources } = require('./content/sources');
const { parseAspects } = require('./content/aspects-parser');
const LEGAL = require('./content/legal');
const POLES = require('./content/ksa-poles');
const { FORMS, buildForm, buildImplementation } = require('./gen/forms');
const X = require('./gen/xlsx');
const { saveVersion } = require('./store');

const COUNTRIES = ['EG', 'SA'];
const TODAY = new Date().toISOString().slice(0, 10);
const RAW = path.join(__dirname, '..', 'sources', 'raw');
const EXCLUDED = new Set(['SA-P-IMS', 'SA-S-RIYADH50001']);

const REGISTERS = {
  'R-ASPECTS': ['Environmental aspects & impacts register', 'سجل الجوانب والآثار البيئية', ['6.1.2E'], 'Significant aspects determined with the FP-103-05 criteria'],
  'R-HIRA': ['Hazard identification & risk assessment register', 'سجل تحديد الأخطار وتقييم المخاطر', ['6.1.2H', '8.1.2'], 'Hazards, risk scores and control type per the hierarchy'],
  'R-LEGAL': ['Legal & other requirements register', 'سجل المتطلبات القانونية', ['6.1.3', '9.1.2'], 'Obligations and their compliance evaluation results'],
  'R-STAKE': ['Interested parties register', 'سجل الأطراف المعنية', ['4.2'], 'Needs, expectations and obligation decision'],
  'R-RO': ['Risks & opportunities register', 'سجل المخاطر والفرص', ['6.1.1', '6.1.4'], 'System-level risks and opportunities with action references'],
  'R-OBJ': ['Objectives & programme register', 'سجل الأهداف والبرامج', ['6.2'], 'Objectives, indicators, owners, proposed vs approved targets'],
  'R-TRAIN': ['Competence & qualification matrix', 'مصفوفة الكفاءات', ['7.2'], 'Required training and licences with expiry'],
  'R-MONITOR': ['Monitoring, measurement & calibration plan', 'خطة المراقبة والقياس والمعايرة', ['9.1.1'], 'Parameters, limits and calibration due dates'],
  'R-AUDIT': ['Internal audit programme & checklist', 'برنامج وقائمة التدقيق الداخلي', ['9.2'], 'Programme across all subclauses; checklist generated from audit checks'],
  'R-MEETINGS': ['Meeting index (minutes, actions, owners)', 'فهرس الاجتماعات', ['5.4', '9.3', '7.4'], 'Index of actual meetings found in sources'],
};

async function hasData() { try { return (await q.get('SELECT COUNT(*) c FROM nodes')).c > 0; } catch { return false; } }

async function wipe() {
  for (const t of ['doc_links', 'doc_versions', 'actions', 'confirmations', 'aspects', 'hira', 'legal']) await q.run(`DELETE FROM ${t}`);
  await q.run('UPDATE documents SET form_doc_id=NULL'); await q.run('DELETE FROM documents');
  for (const t of ['node_country', 'node_reqs', 'nodes', 'requirements', 'sources']) await q.run(`DELETE FROM ${t}`);
}

// Multi-row insert (keeps the first seed fast against a remote database).
async function bulk(table, cols, rows, chunk = 200) {
  for (let i = 0; i < rows.length; i += chunk) {
    const part = rows.slice(i, i + chunk);
    await q.run(`INSERT INTO ${table} (${cols.join(',')}) VALUES ${part.map(() => '(' + cols.map(() => '?').join(',') + ')').join(',')}`, ...part.flat());
  }
}

async function seed({ force = false } = {}) {
  await migrate();
  if (await hasData() && !force) { console.log('Database already seeded — use --force to rebuild content (users and audit log are kept).'); await ensureAdmin(); return; }
  if (force && process.env.IHSE_ALLOW_RESEED !== '1') throw new Error('Refusing --force: it deletes all documents, uploads, actions and confirmations. Take a backup, then set IHSE_ALLOW_RESEED=1.');
  // The whole seed is one transaction: an interrupted first start leaves an empty database, never a half-seeded one.
  await tx(async () => {
    await q.get('SELECT pg_advisory_xact_lock(424242)');
    if (force) await wipe(); else if (await hasData()) return;
    await seedContent();
  });
  await ensureAdmin();
  console.log('Seed complete:', (await q.get('SELECT COUNT(*) c FROM documents')).c, 'documents,', (await q.get('SELECT COUNT(*) c FROM confirmations')).c, 'confirmations');
}

async function seedContent() {

  // ---- structure
  const reqs = requirements();
  const now = new Date().toISOString().replace('T', ' ').slice(0, 19);
  await tx(async () => {
    await bulk('requirements', ['id', 'standard', 'ref', 'title', 'paraphrase', 'applicability', 'sort'], reqs.map((r, i) => [r.id, r.standard, r.ref, r.title, r.paraphrase, r.applicability, i]));
    await bulk('nodes', ['code', 'clause', 'folder', 'title_en', 'title_ar', 'summary_en', 'summary_ar', 'method', 'roles', 'steps', 'audit', 'sort'],
      nodes().map((n, i) => [n.code, n.clause, n.folder, n.en, n.ar, n.summary_en, n.summary_ar, n.method, JSON.stringify(n.roles), JSON.stringify(n.steps), JSON.stringify(n.audit), i]));
    await bulk('node_reqs', ['node_code', 'req_id'], nodes().flatMap(n => [...n.s45.map(r => [n.code, 'ISO45001:' + r]), ...n.s14.map(r => [n.code, 'ISO14001:' + r])]));
    await bulk('node_country', ['node_code', 'country', 'impl', 'status', 'responsible', 'updated_at'], nodes().flatMap(n => COUNTRIES.map(c => [n.code, c, n[c].impl, n[c].status, (n.roles[0] || '').split(':')[0], now])));
    await bulk('sources', ['id', 'country', 'kind', 'node_code', 'filename', 'location', 'url', 'size', 'modified', 'access', 'intended_use', 'note'],
      sources().map(s => [s.id, s.country, s.kind, s.node || null, s.filename, s.location, s.url, s.size, s.modified || null, EXCLUDED.has(s.id) ? 'excluded' : s.access, s.use, s.note]));
  });

  // ---- confirmations
  const conf = [];
  const counter = { EG: 0, SA: 0, GL: 0 };
  const add = (country, node, missing, why, proposed, person, prio) => conf.push([`CR-${country}-${String(++counter[country]).padStart(4, '0')}`, country, node, missing, why, proposed || null, person, person, prio, 'open', now]);
  add('GL', null, 'Published ISO 45001:2018 (with Amd 1:2024) licensed copy. The uploaded "ISO_45001_2018.pdf" shows pre-publication draft numbering (8.2 Management of change, 8.3 Outsourcing, 10.1 Incident).', 'Clause numbering in the matrix follows the published edition; the user copy cannot be cited as the controlled reference', 'Obtain the copy from ISO/EOS/SASO store', 'HSE Senior Manager', 'H');
  add('GL', null, 'Approved bilingual Word/Excel templates, HSE-OP-103 design reference and Excel styles 07–10 as design files', 'Not found as design files in the accessible folders; a provisional Elsewedy dark-red design is used and labelled PROVISIONAL', '', 'HSE Senior Manager / document controller', 'M');
  add('GL', null, 'Portal role holders: who is administrator, document controller, reviewer/approver for each country', 'Approval workflow needs named, authorised users', '', 'HSE Senior Manager', 'H');
  add('GL', null, 'Certification body transition date to ISO 14001:2026 for each plant (multi-site or separate certificates)', 'Drives the 6.3 transition plan and audit scheduling', '', 'HSE Senior Manager (SGS)', 'M');
  nodes().forEach(n => COUNTRIES.forEach(c => n[c].gaps.forEach(g => add(c, n.code, g[0], g[1], g[2], g[3], g[4]))));
  await bulk('confirmations', ['id', 'country', 'node_code', 'missing', 'why', 'proposed', 'source_person', 'owner', 'priority', 'status', 'updated_at'], conf);

  // ---- registers data
  const files = ['EG_aspects_register_FP-103-05.txt', 'EG_aspects_register_FP-103-05_part2.txt'].map(f => path.join(RAW, f)).filter(fs.existsSync);
  const ACOLS = ['country', 'department', 'aspect_en', 'aspect_ar', 'impact_en', 'impact_ar', 'p1', 's1', 'controls_en', 'controls_ar', 'p2', 's2', 'legal', 'consequence', 'materials', 'corporate', 'lifecycle', 'status', 'source_id', 'significance_override', 'note'];
  const aspectRows = (files.length ? parseAspects(files) : []).map(r => ['EG', r.department, r.aspect_en, r.aspect_ar, r.impact_en, r.impact_ar, r.p1, r.s1, r.controls_en, r.controls_ar, r.p2, r.s2, r.legal, r.consequence, r.materials, r.corporate, r.lifecycle, 'source', 'EG-R-ASPECTS', null, null]);
  POLES.ENV.forEach(e => aspectRows.push(['SA', 'Fiber poles', `${e[1]}: ${e[3]}`, `${e[0]}: ${e[2]}`, e[5], e[4], e[7], e[6], e[9], e[8], null, null, null, null, null, null, null, 'source', 'SA-R-POLES-ENV', e[10],
    `Source method SE-05-F01: effect ${e[6]} × probability ${e[7]} = ${e[6] * e[7]} → ${e[10]}. Significance criteria (0/1) not assessed — CONFIRMATION REQUIRED. English is a portal translation.`]));
  await bulk('aspects', ACOLS, aspectRows, 100);
  await bulk('hira', ['country', 'department', 'activity_ar', 'activity_en', 'hazard_ar', 'hazard_en', 'consequence_ar', 'consequence_en', 'controls_ar', 'controls_en', 'l1', 's1', 'note', 'status', 'source_id'],
    POLES.HIRA.map(h => ['SA', 'Fiber poles', ...h.slice(0, 8), h[8], h[9], [h[10], 'English is a portal translation; residual risk blank in source.'].filter(Boolean).join(' '), 'source', 'SA-R-POLES-RA']));
  await bulk('legal', ['country', 'no', 'instrument', 'ref', 'area', 'hse', 'authority', 'review_note', 'eval_result', 'status', 'source_id'], [
    ...LEGAL.EG.map(l => ['EG', l[0], l[1], l[2], l[3], l[4], null, l[5] || null, 'Not evaluated', /Superseded|Duplicate|Remove/.test(l[5]) ? 'Listed in source — review' : 'Listed in source FP-103-04', 'EG-R-LEGAL']),
    ...LEGAL.SA_CANDIDATES.map((l, i) => ['SA', i + 1, 'CONFIRMATION REQUIRED: ' + l[0], l[1], l[2], 'Y', l[3], 'Candidate instrument — not verified for this plant', 'Not evaluated', 'Candidate — confirmation required', null])]);

  // ---- documents
  const insDoc = (d) => q.insert(`INSERT INTO documents (country,code,title_en,title_ar,doc_type,status,origin,source_id,owner,record_date,gen_key,description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    d.country, d.code, d.title_en, d.title_ar || null, d.doc_type, d.status, d.origin, d.source_id || null, d.owner || null, d.record_date || null, d.gen_key || null, d.description || null);
  const link = async (docId, node, rel) => { if (node) await q.run('INSERT OR IGNORE INTO doc_links VALUES (?,?,?)', docId, node, rel || null); };
  const formIds = { EG: {}, SA: {} };

  for (const c of COUNTRIES) {
    for (const [key, f] of Object.entries(FORMS)) {
      const code = `IHSE-${c}-${key}`;
      const id = Number(await insDoc({ country: c, code, title_en: f.en, title_ar: f.ar, doc_type: 'form', status: 'draft', origin: 'generated', gen_key: key, owner: 'HSE Section Head', description: 'Blank bilingual master form' }));
      formIds[c][key] = id;
      await saveVersion(id, Buffer.from(await buildForm(key, c, code, TODAY)), `${code}.docx`, 'Generated master form', null);
      for (const nd of f.nodes) await link(id, nd, null);
    }
    for (const [key, r] of Object.entries(REGISTERS)) {
      const code = `IHSE-${c}-${key}`;
      const id = Number(await insDoc({ country: c, code, title_en: r[0], title_ar: r[1], doc_type: 'register', status: 'draft', origin: 'generated', gen_key: key, owner: 'HSE Section Head', description: r[3] }));
      for (const nd of r[2]) await link(id, nd, r[3]);
    }
  }
  // source documents
  for (const s of sources()) {
    if (s.country === 'GL' || EXCLUDED.has(s.id)) continue;
    // Empty folders are never registered as records or registers — only as sources showing the gap.
    const type = s.access === 'empty' ? 'source' : ({ procedure: 'procedure', form: 'form', register: 'register', record: 'record', instruction: 'instruction', source: 'source' }[s.kind] || 'source');
    const id = Number(await insDoc({ country: s.country, code: s.id, title_en: s.use, doc_type: type, status: 'review', origin: 'source', source_id: s.id,
      record_date: s.modified || null, description: [s.filename, s.note].filter(Boolean).join(' — ') }));
    await link(id, s.node, s.use);
    if (type === 'record') {
      const t = (s.use + ' ' + s.filename).toLowerCase();
      const fk = /minute|mom|committe/.test(t) ? 'F-MOM' : /drill/.test(t) ? 'F-DRILL' : /incident/.test(t) ? 'F-INC' : /hazard report/.test(t) ? 'F-HAZREP'
        : /training|induction|tbt|awareness/.test(t) ? 'F-TRAIN' : /contractor/.test(t) ? 'F-CONTR' : /moc/.test(t) ? 'F-MOC' : /compliance evaluation/.test(t) ? 'F-COMPEVAL' : null;
      if (fk) await q.run('UPDATE documents SET form_doc_id=? WHERE id=?', formIds[s.country][fk], id);
    }
  }
  // cross-link procedures named in node text (shared procedures explained per requirement)
  for (const n of nodes()) for (const c of COUNTRIES) {
    const ids = [...new Set((n[c].impl.match(/\[([A-Z0-9\-, ]+)\]/g) || []).flatMap(m => m.slice(1, -1).split(',').map(x => x.trim())))];
    for (const sid of ids) { const d = await q.get('SELECT id FROM documents WHERE country=? AND code=?', c, sid); if (d) await link(d.id, n.code, `Cited as evidence for ${n.code} ${n.en}`); }
  }
  // register files (after data docs exist)
  for (const c of COUNTRIES) for (const key of Object.keys(REGISTERS)) await regenerateRegister(c, key);

  // implementation documents per node
  for (const n of nodes()) for (const c of COUNTRIES) {
    const code = `IHSE-${c}-PR-${n.code}`;
    const id = Number(await insDoc({ country: c, code, title_en: `${n.code} ${n.en} — implementation`, title_ar: `${n.ar} — التطبيق`, doc_type: 'procedure', status: 'draft', origin: 'generated', gen_key: 'IMPL:' + n.code, owner: 'HSE Senior Manager', description: 'Subclause implementation document' }));
    await link(id, n.code, 'Subclause implementation document: requirement, method, responsibilities, steps, evidence, gaps, audit checks');
    for (const [key, rel] of n.docs) { if (key === 'DOC-IMPL') continue; const d = await q.get('SELECT id FROM documents WHERE country=? AND gen_key=?', c, key); if (d) await link(d.id, n.code, rel); }
    await regenerateImplementation(c, n.code);
  }

  // ---- source-derived actions (portal review findings; no due dates invented)
  const act = (c, node, src, desc, owner) => q.run(`INSERT INTO actions (country,node_code,source,description,owner,status,origin) VALUES (?,?,?,?,?,'open','portal-review')`, c, node, src, desc, owner);
  await act('EG', '6.1.3', 'Legal evaluation', 'Revise FP-103-04: remove superseded Law 137/1981 and Law 79/1975, merge duplicate rows (4/24, 1/25), remove non-HSE laws, confirm COVID-19 decrees, add "how it applies".', 'HSE Section Head');
  await act('EG', '7.5', 'Inspection', 'Resolve duplicate controlled versions of HSE-OP-107 and HSE-OP-120 in "ISO 2026/00 Procedures"; archive the superseded version.', 'Document controller');
  await act('EG', '8.2', 'Inspection', 'Update circulation/evacuation plan A1 (dated 10-2020) for the current or new factory layout.', 'HSE Section Head');
  await act('SA', '6.1.3', 'Legal evaluation', 'Build the Saudi legal register (verify candidate instruments, add licences and permits with expiry dates).', 'KSA HSE lead');
  await act('SA', '6.1.2H', 'Risk assessment', 'Fiber poles risk assessment QA-08-F01: correct mismatched hazard/consequence rows (welfare/COVID/earthquake) and add residual-risk scoring.', 'KSA HSE lead');
  await act('SA', '4.4', 'Inspection', 'Replace unadapted Egypt copies in "0-KSA HSEMS/2026" with KSA-specific records or remove them to avoid false evidence.', 'KSA document controller');

  await log(null, 'seed', 'system', null, null, { requirements: reqs.length, nodes: nodes().length });
}

// Creates the first administrator. On a serverless host there is no writable disk, so IHSE_ADMIN_PASSWORD must be set.
async function ensureAdmin() {
  if (await q.get('SELECT id FROM users LIMIT 1')) return;
  let pw = process.env.IHSE_ADMIN_PASSWORD;
  if (!pw && process.env.VERCEL) { console.warn('IHSE_ADMIN_PASSWORD is not set — no administrator created.'); return; }
  if (!pw) {
    pw = crypto.randomBytes(9).toString('base64url');
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const f = path.join(DATA_DIR, 'INITIAL_ADMIN_PASSWORD.txt'); fs.writeFileSync(f, pw + '\n', { mode: 0o600 });
    console.log('Initial admin password written to ' + f + ' — change it after first login and delete the file.');
  }
  await q.run("INSERT INTO users (username,name,pw_hash,role,countries) VALUES ('admin','Portal administrator',?,'admin','EG,SA')", bcrypt.hashSync(pw, 10));
}

// Called on every cold start: migrates, seeds an empty database once (advisory lock prevents two instances seeding together).
let ready = null;
function ensureReady() {
  if (!ready) ready = (async () => {
    await seed();
  })().catch(e => { ready = null; throw e; });
  return ready;
}

async function regenerateRegister(country, key) {
  const d = await q.get('SELECT * FROM documents WHERE country=? AND gen_key=?', country, key);
  if (!d) return;
  const buf = key === 'R-ASPECTS' ? await X.aspects(country, d.code) : key === 'R-HIRA' ? await X.hira(country, d.code) : key === 'R-LEGAL' ? await X.legal(country, d.code)
    : key === 'R-AUDIT' ? await X.audit(country, d.code) : key === 'R-MEETINGS' ? await X.meetings(country, d.code) : await X.master(key, country, d.code);
  await saveVersion(d.id, Buffer.from(buf), `${d.code}.xlsx`, 'Generated from portal data', null);
}

async function regenerateImplementation(country, nodeCode, userId, note) {
  const d = await q.get('SELECT * FROM documents WHERE country=? AND gen_key=?', country, 'IMPL:' + nodeCode);
  const node = await q.get('SELECT * FROM nodes WHERE code=?', nodeCode);
  const nc = await q.get('SELECT * FROM node_country WHERE node_code=? AND country=?', nodeCode, country);
  const reqs = await q.all('SELECT r.* FROM requirements r JOIN node_reqs nr ON nr.req_id=r.id WHERE nr.node_code=? ORDER BY r.sort', nodeCode);
  const docs = await q.all("SELECT d.code,d.title_en,d.doc_type,l.relevance FROM documents d JOIN doc_links l ON l.doc_id=d.id WHERE l.node_code=? AND d.country=? AND d.doc_type IN ('procedure','policy','form','register','instruction') AND d.id<>? ORDER BY d.doc_type,d.code", nodeCode, country, d.id);
  const records = await q.all("SELECT d.title_en,d.record_date,s.location FROM documents d JOIN doc_links l ON l.doc_id=d.id LEFT JOIN sources s ON s.id=d.source_id WHERE l.node_code=? AND d.country=? AND d.doc_type='record'", nodeCode, country);
  const gaps = await q.all("SELECT * FROM confirmations WHERE node_code=? AND country=? AND status<>'resolved'", nodeCode, country);
  const buf = await buildImplementation({ node, country, code: d.code, impl: nc.impl, status: nc.status, reqs, docs, records, gaps, issueDate: TODAY });
  await saveVersion(d.id, Buffer.from(buf), `${d.code}.docx`, note || 'Generated from portal data', userId || null);
}

module.exports = { seed, ensureReady, regenerateRegister, regenerateImplementation, REGISTERS, COUNTRIES };

if (require.main === module) seed({ force: process.argv.includes('--force') }).catch(e => { console.error(e); process.exit(1); });
