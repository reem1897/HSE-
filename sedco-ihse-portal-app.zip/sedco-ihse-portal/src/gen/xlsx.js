'use strict';
// Excel register builders (ExcelJS). Every workbook: bilingual Instructions sheet, frozen bilingual header, filters,
// validation lists, conditional formatting, formulas where scoring applies, landscape fit-to-width print setup.
const ExcelJS = require('exceljs');
const { q } = require('../db');

const RED = 'FF8B1A1A', LIGHT = 'FFF3E9E9', YELLOW = 'FFFFF59D';
const CN = { EG: 'Egypt plant — Elsewedy Cable Accessories (SEDCO)', SA: 'KSA plant — Elsewedy Industrial Limited, Riyadh (cable accessories & fiber poles)', GL: 'Both plants' };

function newBook() { const wb = new ExcelJS.Workbook(); wb.creator = 'IHSE Portal'; wb.created = new Date(); return wb; }

function instructions(wb, m) {
  const ws = wb.addWorksheet('Instructions تعليمات', { views: [{ showGridLines: false }] });
  ws.columns = [{ width: 28 }, { width: 70 }, { width: 50 }];
  ws.mergeCells('A1:C1');
  Object.assign(ws.getCell('A1'), { value: `${m.titleEn}  |  ${m.titleAr}` });
  ws.getCell('A1').font = { bold: true, size: 14, color: { argb: 'FFFFFFFF' } };
  ws.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: RED } };
  ws.getRow(1).height = 28;
  const rows = [
    ['Site / الموقع', CN[m.country] || m.country, ''],
    ['Code / الكود', m.code, ''],
    ['Status / الحالة', m.status || 'Draft — pending approval / مسودة بانتظار الاعتماد', ''],
    ['Generated / تاريخ الإصدار', new Date().toISOString().slice(0, 10), 'Exported from the IHSE portal database'],
    ['Design / التصميم', 'PROVISIONAL bilingual design (approved company Excel styles 07–10 not supplied)', ''],
    ['', '', ''],
    ['How to use / طريقة الاستخدام', '', ''],
    ...(m.instructions || []).map(t => ['', t, '']),
    ['', '', ''],
    ['Legend / مفتاح الألوان', '', ''],
    ['Yellow cell', 'CONFIRMATION REQUIRED — the value is unknown or unverified; the text says what is missing. يلزم التأكيد', ''],
    ['Provenance', 'Rows marked "Source:" were transcribed from the named company file; rows without it were entered in the portal.', ''],
    ...(m.legend || []).map(([a, b]) => [a, b, '']),
  ];
  rows.forEach((r, i) => {
    const row = ws.getRow(i + 2); row.values = r;
    row.getCell(1).font = { bold: true }; row.alignment = { wrapText: true, vertical: 'top' };
    if (r[0] === 'Yellow cell') row.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: YELLOW } };
  });
  ws.pageSetup = { orientation: 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9 };
  return ws;
}

// cols: [{key, en, ar, width, list?:[], wrap?}]
function dataSheet(wb, name, cols, rows, m = {}) {
  const ws = wb.addWorksheet(name, { views: [{ state: 'frozen', ySplit: 1, xSplit: m.freezeCols || 0 }] });
  ws.columns = cols.map(c => ({ key: c.key, width: c.width || 18 }));
  const head = ws.getRow(1);
  cols.forEach((c, i) => {
    const cell = head.getCell(i + 1);
    cell.value = `${c.en}\n${c.ar || ''}`;
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: RED } };
    cell.alignment = { wrapText: true, vertical: 'middle', horizontal: 'center' };
    cell.border = { bottom: { style: 'thin' } };
  });
  head.height = 42;
  rows.forEach(r => {
    const row = ws.addRow(cols.map(c => r[c.key] === undefined ? null : r[c.key]));
    row.alignment = { wrapText: true, vertical: 'top' };
    cols.forEach((c, i) => {
      const v = r[c.key]; const cell = row.getCell(i + 1);
      if (typeof v === 'string' && /CONFIRMATION REQUIRED|يلزم التأكيد/.test(v)) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: YELLOW } };
      if (c.rtl) cell.alignment = { wrapText: true, vertical: 'top', horizontal: 'right', readingOrder: 'rtl' };
      if (c.formula) cell.value = { formula: c.formula(row.number), result: undefined };
    });
  });
  const last = Math.max(ws.rowCount, 2);
  const extra = m.blankRows ?? 0;
  for (let i = 0; i < extra; i++) {
    const row = ws.addRow([]);
    cols.forEach((c, j) => { if (c.formula) row.getCell(j + 1).value = { formula: c.formula(row.number) }; });
  }
  const end = ws.rowCount;
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: cols.length } };
  cols.forEach((c, i) => {
    if (!c.list) return;
    const col = ws.getColumn(i + 1).letter;
    ws.dataValidations.add(`${col}2:${col}${Math.max(end, 500)}`, { type: 'list', allowBlank: true, formulae: [`"${c.list.join(',')}"`], showErrorMessage: true, errorTitle: 'Invalid value', error: 'Choose from the list' });
  });
  (m.conditional || []).forEach(cf => ws.addConditionalFormatting({ ref: cf.ref.replace('{end}', Math.max(end, 500)), rules: cf.rules }));
  ws.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9, printTitlesRow: '1:1', margins: { left: 0.4, right: 0.4, top: 0.6, bottom: 0.6, header: 0.3, footer: 0.3 } };
  ws.headerFooter = { oddHeader: `&L${m.code || ''}&C${m.titleEn || name}&R&D`, oddFooter: '&LUncontrolled when printed&RPage &P of &N' };
  return ws;
}

const bandRules = (col) => [
  { type: 'expression', priority: 1, formulae: [`AND(ISNUMBER(${col}2),${col}2>12)`], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFF4B6B6' } } } },
  { type: 'expression', priority: 2, formulae: [`AND(ISNUMBER(${col}2),${col}2>6,${col}2<=12)`], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFFFE0A3' } } } },
  { type: 'expression', priority: 3, formulae: [`AND(ISNUMBER(${col}2),${col}2<=6)`], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFD7EBD7' } } } },
];
// Expression-based "contains text" rule (works consistently in Excel and LibreOffice; numeric cells never match).
const textRule = (text, argb, p = 5, first = 'A2') => ({ type: 'expression', priority: p, formulae: [`ISNUMBER(SEARCH("${text}",${first}))`], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb } } } });
const CONF = 'CONFIRMATION REQUIRED';
const scale = ['1', '2', '3', '4', '5'];

// ------------------------------------------------------------------ registers
async function aspects(country, code) {
  const rows = (await q.all('SELECT * FROM aspects WHERE country=? ORDER BY id', country));
  const wb = newBook();
  const m = { country, code, titleEn: 'Environmental aspects & impacts register', titleAr: 'سجل الجوانب والآثار البيئية', instructions: [
    'One row per aspect per department/area. Rate probability (P) and severity (S) 1–5 before and after controls; Rating = P × S (formula).',
    'Bands (company method FP-103-05): ≤6 Low, 7–12 Medium, >12 High.',
    'Significance criteria (0/1 each): legal requirement, environmental consequence, use of materials, corporate concerns. Total >1 = Significant (formula).',
    'Consider life-cycle stages, abnormal and emergency conditions, climate mitigation/adaptation, biodiversity and circularity (ISO 14001:2026 4.1, 6.1.2).',
    country === 'SA' ? 'KSA: fiber poles rows were transcribed from SE-05-F01 (1 Jan 2025), which used a different significance method; they keep the source result in "Note". Cable accessories departments: CONFIRMATION REQUIRED — assessment not found.' : 'Egypt: rows imported from FP-103-05 2026 (source EG-R-ASPECTS). Approval of the 2026 revision is not confirmed.',
  ] };
  instructions(wb, m);
  const cols = [
    { key: 'department', en: 'Department / area', ar: 'القسم', width: 18 },
    { key: 'aspect_en', en: 'Aspect', ar: 'الجانب البيئي', width: 26 },
    { key: 'aspect_ar', en: 'Aspect (Arabic)', ar: 'الجانب (عربي)', width: 22, rtl: true },
    { key: 'impact_en', en: 'Impact', ar: 'الأثر', width: 30 },
    { key: 'p1', en: 'P before', ar: 'الاحتمال قبل', width: 9, list: scale },
    { key: 's1', en: 'S before', ar: 'الشدة قبل', width: 9, list: scale },
    { key: 'r1', en: 'Rating before', ar: 'التقييم قبل', width: 10, formula: n => `IF(AND(ISNUMBER(E${n}),ISNUMBER(F${n})),E${n}*F${n},"")` },
    { key: 'controls_en', en: 'Controls', ar: 'الضوابط', width: 40 },
    { key: 'p2', en: 'P after', ar: 'الاحتمال بعد', width: 9, list: scale },
    { key: 's2', en: 'S after', ar: 'الشدة بعد', width: 9, list: scale },
    { key: 'r2', en: 'Rating after', ar: 'التقييم بعد', width: 10, formula: n => `IF(AND(ISNUMBER(I${n}),ISNUMBER(J${n})),I${n}*J${n},"")` },
    { key: 'legal', en: 'Legal (0/1)', ar: 'قانوني', width: 8, list: ['0', '1'] },
    { key: 'consequence', en: 'Env. consequence (0/1)', ar: 'العاقبة البيئية', width: 10, list: ['0', '1'] },
    { key: 'materials', en: 'Use of materials (0/1)', ar: 'استخدام المواد', width: 10, list: ['0', '1'] },
    { key: 'corporate', en: 'Corporate concern (0/1)', ar: 'اهتمام الشركة', width: 10, list: ['0', '1'] },
    { key: 'total', en: 'Total', ar: 'المجموع', width: 8, formula: n => `SUM(L${n}:O${n})` },
    { key: 'sig', en: 'Significant?', ar: 'هام؟', width: 14, formula: n => `IF(COUNT(L${n}:O${n})=0,"",IF(P${n}>1,"Significant","Not significant"))` },
    { key: 'lifecycle', en: 'Life-cycle / climate row', ar: 'دورة الحياة/المناخ', width: 10 },
    { key: 'note', en: 'Note / provenance', ar: 'ملاحظة / المصدر', width: 30 },
  ];
  const data = rows.map(r => ({ ...r, note: [r.note, r.source_id ? 'Source: ' + r.source_id : ''].filter(Boolean).join(' | ') }));
  if (country === 'SA') data.push({ department: 'Cable accessories departments', aspect_en: 'CONFIRMATION REQUIRED: KSA cable accessories aspects not assessed in available sources', note: 'See confirmation register' });
  dataSheet(wb, 'Register السجل', cols, data, { code, titleEn: m.titleEn, blankRows: 20, freezeCols: 2, conditional: [
    { ref: 'G2:G{end}', rules: bandRules('G') }, { ref: 'K2:K{end}', rules: bandRules('K') },
    { ref: 'Q2:Q{end}', rules: [textRule('Not significant', 'FFE6E6E6', 4, 'Q2'), { type: 'expression', priority: 5, formulae: ['Q2="Significant"'], style: { fill: { type: 'pattern', pattern: 'solid', bgColor: { argb: 'FFF4B6B6' } } } }] },
    { ref: 'A2:S{end}', rules: [textRule(CONF, YELLOW, 6)] },
  ] });
  return wb.xlsx.writeBuffer();
}

async function hira(country, code) {
  const rows = (await q.all('SELECT * FROM hira WHERE country=? ORDER BY id', country));
  const wb = newBook();
  const m = { country, code, titleEn: 'Hazard identification & OH&S risk assessment register', titleAr: 'سجل تحديد الأخطار وتقييم المخاطر', instructions: [
    'One row per task/activity hazard. Include routine and non-routine work, contractors, human factors and emergencies (ISO 45001 6.1.2.1).',
    'Risk = Likelihood (L) × Severity (S), 1–5 each (formula). ≤6 Low; 7–12 Medium (extra controls before work starts); >12 High.',
    'Proposed OH&S severity scale (pending approval): 1 first aid, 2 medical treatment, 3 lost time <30 days, 4 permanent disability, 5 fatality.',
    'Record the main control type using the hierarchy of controls (ISO 45001 8.1.2) and re-score after additional controls.',
    country === 'SA' ? 'KSA: fiber poles rows transcribed from QA-08-F01 (1/1/2025). Residual scores are blank in the source and remain blank.' : 'Egypt: company registers JHA.xlsx and Risk register.xlsx (EG-R-JHA, EG-R-RISKREG) are the live sources; they were not imported. Use this master or link the originals.',
  ] };
  instructions(wb, m);
  const cols = [
    { key: 'department', en: 'Department', ar: 'القسم', width: 14 },
    { key: 'activity_en', en: 'Activity', ar: 'النشاط', width: 22 }, { key: 'activity_ar', en: 'Activity (Arabic)', ar: 'النشاط (عربي)', width: 20, rtl: true },
    { key: 'hazard_en', en: 'Hazard', ar: 'الخطر', width: 22 }, { key: 'consequence_en', en: 'Consequence', ar: 'العواقب', width: 28 },
    { key: 'controls_en', en: 'Existing controls', ar: 'الإجراءات الحالية', width: 36 },
    { key: 'l1', en: 'L', ar: 'الاحتمالية', width: 7, list: scale }, { key: 's1', en: 'S', ar: 'الشدة', width: 7, list: scale },
    { key: 'r1', en: 'Risk', ar: 'مستوى الخطر', width: 8, formula: n => `IF(AND(ISNUMBER(G${n}),ISNUMBER(H${n})),G${n}*H${n},"")` },
    { key: 'control_type', en: 'Main control type', ar: 'نوع الضابط', width: 14, list: ['Elimination', 'Substitution', 'Engineering', 'Administrative', 'PPE'] },
    { key: 'extra_controls', en: 'Additional controls', ar: 'إجراءات إضافية', width: 28 },
    { key: 'l2', en: 'L after', ar: 'الاحتمالية بعد', width: 7, list: scale }, { key: 's2', en: 'S after', ar: 'الشدة بعد', width: 7, list: scale },
    { key: 'r2', en: 'Residual risk', ar: 'الخطر المتبقي', width: 9, formula: n => `IF(AND(ISNUMBER(L${n}),ISNUMBER(M${n})),L${n}*M${n},"")` },
    { key: 'note', en: 'Note / provenance', ar: 'ملاحظة / المصدر', width: 30 },
  ];
  const data = rows.map(r => ({ ...r, note: [r.note, r.source_id ? 'Source: ' + r.source_id : ''].filter(Boolean).join(' | ') }));
  if (country === 'SA') data.push({ department: 'Cable accessories', activity_en: 'CONFIRMATION REQUIRED: cable accessories HIRA not found in KSA sources (2026 files are Egypt copies)' });
  if (country === 'EG') data.push({ department: '—', activity_en: 'CONFIRMATION REQUIRED: import or link Egypt JHA / risk register rows (EG-R-JHA, EG-R-RISKREG)' });
  dataSheet(wb, 'HIRA', cols, data, { code, titleEn: m.titleEn, blankRows: 25, freezeCols: 2, conditional: [
    { ref: 'I2:I{end}', rules: bandRules('I') }, { ref: 'N2:N{end}', rules: bandRules('N') }, { ref: 'A2:O{end}', rules: [textRule(CONF, YELLOW, 6)] }] });
  return wb.xlsx.writeBuffer();
}

async function legal(country, code) {
  const rows = (await q.all('SELECT * FROM legal WHERE country=? ORDER BY no, id', country));
  const wb = newBook();
  const m = { country, code, titleEn: 'Legal & other requirements register and compliance evaluation', titleAr: 'سجل المتطلبات القانونية وتقييم الامتثال', instructions: [
    'One row per legal or other requirement. State HOW it applies (department, aspect, hazard, permit). ISO 45001 6.1.3 / ISO 14001 6.1.3.',
    'Compliance evaluation columns satisfy 9.1.2: date, evidence, result. "Not evaluated" means no evidence has been recorded — it is not a pass.',
    country === 'SA' ? 'KSA: candidate Saudi instruments only — every row is CONFIRMATION REQUIRED until verified by KSA legal/HSE. Egyptian legislation is deliberately excluded.' : 'Egypt: rows transcribed from FP-103-04 Rev 01 (3/01/2025). "Review note" holds portal findings (superseded, duplicate, non-HSE).',
  ], legend: [['Result values', 'Compliant / Partially compliant / Not compliant / Not evaluated']] };
  instructions(wb, m);
  const cols = [
    { key: 'no', en: 'No.', ar: 'م', width: 6 }, { key: 'instrument', en: 'Requirement', ar: 'التشريع / المتطلب', width: 44 },
    { key: 'ref', en: 'Number / year', ar: 'الرقم / السنة', width: 18 }, { key: 'area', en: 'Area', ar: 'المجال', width: 18 },
    { key: 'hse', en: 'HSE relevant', ar: 'متعلق بالسلامة والبيئة', width: 9, list: ['Y', 'N'] }, { key: 'authority', en: 'Authority', ar: 'الجهة', width: 22 },
    { key: 'how_applies', en: 'How it applies', ar: 'كيفية التطبيق', width: 30 }, { key: 'review_note', en: 'Review note', ar: 'ملاحظة المراجعة', width: 34 },
    { key: 'eval_date', en: 'Evaluated on', ar: 'تاريخ التقييم', width: 12 },
    { key: 'eval_result', en: 'Result', ar: 'النتيجة', width: 14, list: ['Compliant', 'Partially compliant', 'Not compliant', 'Not evaluated'] },
    { key: 'evidence', en: 'Evidence', ar: 'الدليل', width: 24 }, { key: 'status', en: 'Entry status', ar: 'حالة البند', width: 22 },
  ];
  const data = rows.map(r => ({ ...r, how_applies: r.how_applies || (r.hse === 'Y' ? 'CONFIRMATION REQUIRED: state how this applies' : ''), }));
  dataSheet(wb, 'Register السجل', cols, data, { code, titleEn: m.titleEn, blankRows: 15, freezeCols: 2, conditional: [
    { ref: 'J2:J{end}', rules: [textRule('Not compliant', 'FFF4B6B6', 2, 'J2'), textRule('Partially', 'FFFFE0A3', 3, 'J2'), textRule('Not evaluated', 'FFE6E6E6', 4, 'J2')] },
    { ref: 'A2:L{end}', rules: [textRule(CONF, YELLOW, 6)] },
    { ref: 'H2:H{end}', rules: [textRule('Superseded', 'FFF4B6B6', 7, 'H2'), textRule('Duplicate', 'FFFFE0A3', 8, 'H2')] }] });
  return wb.xlsx.writeBuffer();
}

async function blankRegister(country, code, titleEn, titleAr, cols, instr, extraRows = [], blank = 25) {
  const wb = newBook();
  instructions(wb, { country, code, titleEn, titleAr, instructions: instr });
  dataSheet(wb, 'Register السجل', cols, extraRows, { code, titleEn, blankRows: blank, conditional: [{ ref: `A2:${String.fromCharCode(64 + cols.length)}{end}`, rules: [textRule(CONF, YELLOW, 6)] }] });
  return wb.xlsx.writeBuffer();
}

const MASTERS = {
  'R-STAKE': ['Interested parties register', 'سجل الأطراف المعنية', [
    { key: 'party', en: 'Interested party', ar: 'الطرف المعني', width: 24 }, { key: 'type', en: 'Internal/External', ar: 'داخلي/خارجي', width: 12, list: ['Internal', 'External'] },
    { key: 'need', en: 'Needs & expectations', ar: 'الاحتياجات والتوقعات', width: 40 }, { key: 'climate', en: 'Climate/resource related?', ar: 'متعلق بالمناخ؟', width: 12, list: ['Yes', 'No'] },
    { key: 'obligation', en: 'Becomes compliance obligation?', ar: 'التزام امتثال؟', width: 14, list: ['Yes', 'No'] }, { key: 'legal_ref', en: 'Legal register ref', ar: 'مرجع السجل القانوني', width: 14 },
    { key: 'monitor', en: 'How monitored', ar: 'طريقة المتابعة', width: 24 }, { key: 'owner', en: 'Owner', ar: 'المسؤول', width: 16 }, { key: 'reviewed', en: 'Last reviewed', ar: 'آخر مراجعة', width: 12 }],
    ['List workers and contractor workers first (ISO 45001 4.2).', 'Mark which needs become compliance obligations (ISO 14001:2026 4.2 c) and copy them to the legal register.']],
  'R-RO': ['Risks & opportunities register (system level)', 'سجل المخاطر والفرص', [
    { key: 'source', en: 'Source (4.1 issue / 4.2 need / aspect / obligation)', ar: 'المصدر', width: 26 }, { key: 'type', en: 'Risk/Opportunity', ar: 'خطر/فرصة', width: 12, list: ['Risk', 'Opportunity'] },
    { key: 'desc', en: 'Description', ar: 'الوصف', width: 40 }, { key: 'std', en: 'Standard', ar: 'المعيار', width: 12, list: ['OH&S', 'Environment', 'Both'] },
    { key: 'l', en: 'L', ar: 'الاحتمالية', width: 6, list: scale }, { key: 's', en: 'S', ar: 'الشدة', width: 6, list: scale },
    { key: 'score', en: 'Score', ar: 'الدرجة', width: 8, formula: n => `IF(AND(ISNUMBER(E${n}),ISNUMBER(F${n})),E${n}*F${n},"")` },
    { key: 'action', en: 'Action / reference (6.1.4)', ar: 'الإجراء', width: 30 }, { key: 'owner', en: 'Owner', ar: 'المسؤول', width: 16 }, { key: 'due', en: 'Due', ar: 'الموعد', width: 12 }],
    ['Include external environmental conditions that can affect the plant (heat, water shortage, supply disruption) — ISO 14001:2026 6.1.4.', 'Score with the 5×5 matrix; every score >6 needs an action reference.']],
  'R-OBJ': ['Objectives & programme register', 'سجل الأهداف والبرامج', [
    { key: 'objective', en: 'Objective', ar: 'الهدف', width: 32 }, { key: 'source', en: 'Source (aspect/risk/obligation)', ar: 'المصدر', width: 20 },
    { key: 'indicator', en: 'Indicator & formula', ar: 'المؤشر', width: 24 }, { key: 'baseline', en: 'Baseline (value, date, source)', ar: 'خط الأساس', width: 20 },
    { key: 'target', en: 'Target', ar: 'المستهدف', width: 12 }, { key: 'target_status', en: 'Target status', ar: 'حالة المستهدف', width: 14, list: ['Proposed', 'Approved'] },
    { key: 'actions', en: 'Actions (what)', ar: 'الإجراءات', width: 26 }, { key: 'resources', en: 'Resources', ar: 'الموارد', width: 16 }, { key: 'owner', en: 'Owner', ar: 'المسؤول', width: 14 },
    { key: 'due', en: 'Due', ar: 'الموعد', width: 12 }, { key: 'actual', en: 'Latest measured result', ar: 'آخر نتيجة', width: 14 }, { key: 'result_date', en: 'Result date', ar: 'تاريخ النتيجة', width: 12 }],
    ['Keep proposed targets labelled "Proposed" until approved at management review.', 'Only enter "Latest measured result" from a measurement record — never an estimate.']],
  'R-TRAIN': ['Competence & qualification matrix', 'مصفوفة الكفاءات والتأهيل', [
    { key: 'name', en: 'Employee / ID', ar: 'الموظف', width: 22 }, { key: 'job', en: 'Job title', ar: 'الوظيفة', width: 18 }, { key: 'dept', en: 'Department', ar: 'القسم', width: 14 },
    { key: 'req', en: 'Required training / licence', ar: 'التدريب المطلوب', width: 26 }, { key: 'done', en: 'Completed on', ar: 'تاريخ الإتمام', width: 12 },
    { key: 'expiry', en: 'Valid until', ar: 'صالح حتى', width: 12 }, { key: 'eff', en: 'Effectiveness checked', ar: 'تقييم الفعالية', width: 14, list: ['Yes', 'No', 'Pending'] }, { key: 'evidence', en: 'Evidence ref', ar: 'مرجع الدليل', width: 16 }],
    ['Include forklift/crane licences, PTW issuers, first aiders, fire team, chemical handlers.', 'Expired licences highlight via the "Valid until" filter.']],
  'R-MONITOR': ['Monitoring, measurement & calibration plan', 'خطة المراقبة والقياس والمعايرة', [
    { key: 'param', en: 'Parameter', ar: 'المعامل', width: 24 }, { key: 'area', en: 'Area / point', ar: 'المكان', width: 18 }, { key: 'method', en: 'Method', ar: 'الطريقة', width: 18 },
    { key: 'freq', en: 'Frequency', ar: 'التكرار', width: 12, list: ['Daily', 'Weekly', 'Monthly', 'Quarterly', 'Semi-annual', 'Annual'] }, { key: 'limit', en: 'Limit / criterion (with legal ref)', ar: 'الحد', width: 22 },
    { key: 'unit', en: 'Unit', ar: 'الوحدة', width: 8 }, { key: 'resp', en: 'Responsible', ar: 'المسؤول', width: 14 }, { key: 'equip', en: 'Equipment ID', ar: 'رقم الجهاز', width: 12 },
    { key: 'calib', en: 'Calibration due', ar: 'موعد المعايرة', width: 12 }, { key: 'last', en: 'Last result', ar: 'آخر نتيجة', width: 12 }, { key: 'last_date', en: 'Result date', ar: 'تاريخ النتيجة', width: 12 }],
    ['Typical parameters: noise, illumination, heat stress (WBGT), workplace air, stack emissions, wastewater (pH, BOD, COD, TSS, metals), energy, water, waste quantities, OH&S KPIs.', 'Limits must cite the legal reference in the legal register.']],
  'R-AUDIT': null, 'R-MEETINGS': null,
};

async function master(key, country, code) {
  const d = MASTERS[key];
  return blankRegister(country, code, d[0], d[1], d[2], d[3]);
}

async function meetings(country, code) {
  const recs = (await q.all("SELECT d.*, s.url, s.modified FROM documents d LEFT JOIN sources s ON s.id=d.source_id WHERE d.country=? AND d.doc_type='record' AND EXISTS (SELECT 1 FROM doc_links l WHERE l.doc_id=d.id AND l.node_code IN ('5.4','9.3','4.1','6.2')) ORDER BY d.code", country));
  const rows = recs.filter(r => /minute|mom|committe|management review|mr /i.test(r.title_en + ' ' + (r.description || ''))).map(r => ({
    meeting: r.title_en, date: r.record_date || 'CONFIRMATION REQUIRED: meeting date', attendees: 'CONFIRMATION REQUIRED: attendees not extracted',
    file: r.url || '', actions: 'CONFIRMATION REQUIRED: actions not yet indexed', req: '' }));
  if (!rows.length) rows.push({ meeting: 'CONFIRMATION REQUIRED: no completed minutes found in sources for this country' });
  return blankRegister(country, code, 'Meeting index (minutes, actions, owners)', 'فهرس الاجتماعات والإجراءات', [
    { key: 'meeting', en: 'Meeting / record', ar: 'الاجتماع', width: 34 }, { key: 'type', en: 'Type', ar: 'النوع', width: 16, list: ['HSE committee', 'Management review', 'Context review', 'Objectives review', 'Other'] },
    { key: 'date', en: 'Date', ar: 'التاريخ', width: 16 }, { key: 'attendees', en: 'Attendees', ar: 'الحضور', width: 24 },
    { key: 'actions', en: 'Actions (owner, due)', ar: 'الإجراءات', width: 30 }, { key: 'file', en: 'Minutes file (link)', ar: 'ملف المحضر', width: 40 }, { key: 'req', en: 'Requirements supported', ar: 'المتطلبات', width: 18 }],
    ['Lists ACTUAL meetings from company sources only. The blank bilingual MOM template is a separate document and is not evidence.', 'Enter each action also in the portal action tracker (source "Meeting").'], rows, 15);
}

async function audit(country, code) {
  const wb = newBook();
  instructions(wb, { country, code, titleEn: 'Internal audit programme & checklist', titleAr: 'برنامج التدقيق الداخلي وقائمة الفحص', instructions: [
    'Sheet "Programme": schedule each integrated subclause; higher frequency for high-importance processes.', 'Sheet "Checklist": audit questions generated from the portal for each subclause, with the mapped clauses of both standards. Record evidence seen and the finding.'] });
  const nodes = (await q.all('SELECT * FROM nodes ORDER BY sort'));
  const map = {}; (await q.all('SELECT * FROM node_reqs')).forEach(r => (map[r.node_code] = map[r.node_code] || []).push(r.req_id.replace('ISO45001:', '45001 ').replace('ISO14001:', '14001 ')));
  dataSheet(wb, 'Programme البرنامج', [
    { key: 'code', en: 'Subclause', ar: 'البند', width: 10 }, { key: 'title', en: 'Process / topic', ar: 'العملية', width: 40 }, { key: 'clauses', en: 'Standard clauses', ar: 'بنود المعيار', width: 30 },
    { key: 'importance', en: 'Importance', ar: 'الأهمية', width: 12, list: ['High', 'Medium', 'Low'] }, { key: 'q1', en: 'Q1', ar: 'ر1', width: 6, list: ['X'] }, { key: 'q2', en: 'Q2', ar: 'ر2', width: 6, list: ['X'] },
    { key: 'q3', en: 'Q3', ar: 'ر3', width: 6, list: ['X'] }, { key: 'q4', en: 'Q4', ar: 'ر4', width: 6, list: ['X'] }, { key: 'auditor', en: 'Auditor (independent)', ar: 'المدقق', width: 18 }],
    nodes.map(n => ({ code: n.code, title: n.title_en, clauses: (map[n.code] || []).join(', ') })), { code, titleEn: 'Internal audit programme' });
  const rows = [];
  nodes.forEach(n => JSON.parse(n.audit || '[]').forEach(qq => rows.push({ code: n.code, clauses: (map[n.code] || []).join(', '), question: qq })));
  dataSheet(wb, 'Checklist قائمة الفحص', [
    { key: 'code', en: 'Subclause', ar: 'البند', width: 10 }, { key: 'clauses', en: 'Clauses', ar: 'البنود', width: 24 }, { key: 'question', en: 'Audit question', ar: 'سؤال التدقيق', width: 60 },
    { key: 'evidence', en: 'Evidence seen', ar: 'الدليل', width: 30 }, { key: 'finding', en: 'Finding', ar: 'النتيجة', width: 16, list: ['Conforms', 'Minor NC', 'Major NC', 'Observation', 'OFI'] }, { key: 'ref', en: 'Action ref', ar: 'مرجع الإجراء', width: 12 }],
    rows, { code, titleEn: 'Internal audit checklist', conditional: [{ ref: 'E2:E{end}', rules: [textRule('Major', 'FFF4B6B6', 1, 'E2'), textRule('Minor', 'FFFFE0A3', 2, 'E2')] }] });
  return wb.xlsx.writeBuffer();
}

// ---------------------------------------------------------------- live exports
async function tableExport(titleEn, titleAr, country, code, cols, rows, instr) {
  const wb = newBook();
  instructions(wb, { country, code, titleEn, titleAr, status: 'Live export from portal database', instructions: instr });
  dataSheet(wb, 'Data البيانات', cols, rows, { code, titleEn, conditional: [{ ref: `A2:${String.fromCharCode(64 + cols.length)}{end}`, rules: [textRule(CONF, YELLOW, 6)] }] });
  return wb.xlsx.writeBuffer();
}

module.exports = { aspects, hira, legal, master, meetings, audit, tableExport, MASTERS };
