'use strict';
// Egypt: entries transcribed from company list FP-103-04 Rev 01 (3/01/2025) [EG-R-LEGAL]; the review notes are portal findings.
// KSA: CANDIDATE instruments only — not verified, never shown as obligations until confirmed by KSA legal/HSE.

// [no, instrument, year/number, area, hse (Y/N), review note]
const EG = [
  [1, 'Labour Law (Book 4 arts. 224–226; Book 6 arts. 227–228 — OSH)', 'Law 14 / 2025', 'OH&S', 'Y', ''],
  [2, 'Social Insurance and Pensions Law + executive regulation 2437/2021', 'Law 148 / 2019', 'OH&S (work injury insurance)', 'Y', ''],
  [3, 'Law facilitating industrial licences + executive regulation 1082/2017', 'Law 15 / 2017', 'Licensing', 'Y', 'Link the plant licence and its expiry'],
  [4, 'Environment Law, amended by Law 9/2009, with executive regulation', 'Law 4 / 1994', 'Environment', 'Y', 'Listed twice (rows 4 and 24) — merge'],
  [5, 'Law amending certain provisions of the Environment Law', 'Law 105 / 2015', 'Environment', 'Y', ''],
  [6, 'Investment Law + executive regulation 2310/2017', 'Law 72 / 2017', 'General business', 'N', 'Not an HSE obligation — consider removing'],
  [7, 'Competition protection law + executive regulation 1316/2005', 'Law 3 / 2005', 'General business', 'N', 'Not an HSE obligation — consider removing'],
  [8, 'Export development law', 'Law 155 / 2002', 'General business', 'N', 'Not an HSE obligation — consider removing'],
  [9, 'Waste Management Regulation Law + executive regulation 722/2022', 'Law 202 / 2020', 'Environment (waste)', 'Y', ''],
  [10, 'Consumer protection law', 'Law 67 / 2006', 'General business', 'N', 'Not an HSE obligation — consider removing'],
  [11, 'Child Law + executive regulation 2075/2010 (child labour)', 'Law 12 / 1996', 'OH&S (young workers)', 'Y', ''],
  [12, 'Law amending the Child Law', 'Law 126 / 2008', 'OH&S (young workers)', 'Y', ''],
  [13, 'Electric elevators law + executive regulation 241/1975', 'Law 78 / 1975', 'OH&S (lifts)', 'Y', ''],
  [14, 'Tax law + executive regulation 991/2005', 'Law 91 / 2005', 'General business', 'N', 'Not an HSE obligation — consider removing'],
  [15, 'Sales tax law + executive regulation 749/2001', 'Law 11 / 1991', 'General business', 'N', 'Not an HSE obligation — consider removing'],
  [16, 'Labour law (listed as "new labour law", OSH)', 'Law 137 / 1981', 'OH&S', 'Y', 'Superseded — repealed by later labour laws; current is Law 14/2025. Remove.'],
  [17, 'Minister of Manpower decree — organisation of industrial safety bodies', 'Decree 7 / 1972', 'OH&S', 'Y', 'Confirm still in force under Law 14/2025'],
  [18, 'Minister of Manpower decree — OSH bodies and training entities', 'Decree 116 / 1991', 'OH&S', 'Y', 'Confirm still in force under Law 14/2025'],
  [19, 'Decree on installation and operation of steam boilers', 'Decree 55 / 1977', 'OH&S (pressure equipment)', 'Y', 'Applies only if boilers exist — confirm'],
  [20, 'Decree on heat engines and steam boilers', 'Decree 49 / 1978', 'OH&S (pressure equipment)', 'Y', 'Applies only if boilers exist — confirm'],
  [21, 'Minister of Labour decree — precautions protecting workers from health hazards', 'Decree 8 / 1958', 'OH&S', 'Y', 'Confirm still in force'],
  [22, 'Ministry of Manpower decree — safety precautions and protection from hazards', 'Decree 55 / 1983', 'OH&S', 'Y', 'Confirm still in force'],
  [23, 'Social insurance law (work injury insurance)', 'Law 79 / 1975', 'OH&S', 'Y', 'Superseded by Law 148/2019. Remove.'],
  [24, 'Environment Law (duplicate entry)', 'Law 4 / 1994', 'Environment', 'Y', 'Duplicate of row 4'],
  [25, 'Labour Law (duplicate entry)', 'Law 14 / 2025', 'OH&S', 'Y', 'Duplicate of row 1'],
  [26, 'Prime Minister decree (title not stated in source)', 'Decree 1095 / 2011', 'Unknown', 'Y', 'Title missing — confirm subject (possibly Environment Law executive regulation amendment)'],
  [27, 'Prime Minister decree (title not stated in source)', 'Decree 710 / 2012', 'Unknown', 'Y', 'Title missing — confirm subject'],
  [28, 'Prime Minister decree (title not stated in source)', 'Decree 964 / 2015', 'Unknown', 'Y', 'Title missing — confirm subject'],
  [29, 'Traffic law', 'Law 121 / 2008', 'OH&S (driving)', 'Y', 'Relevant to journey management (HSE-OP-112)'],
  [30, 'Prime Minister decree — official holidays', 'Decree 1193 / 2018', 'General', 'N', 'Not an HSE obligation'],
  [31, 'Prime Minister decree — COVID-19 measures', 'Decree 719 / 2020', 'OH&S (pandemic)', 'Y', 'Temporary measure — confirm whether still in force'],
  [32, 'Prime Minister decree — COVID-19 measures', 'Decree 768 / 2020', 'OH&S (pandemic)', 'Y', 'Temporary measure — confirm whether still in force'],
  [33, 'Prime Minister decree — COVID-19 measures', 'Decree 939 / 2020', 'OH&S (pandemic)', 'Y', 'Temporary measure — confirm whether still in force'],
  [34, 'Law on COVID-19 measures', 'Law 152 / 2021', 'OH&S (pandemic)', 'Y', 'Confirm whether still in force'],
  [35, 'Prime Minister decree — entry restriction for unvaccinated persons', 'Decree 2750 / 2021', 'OH&S (pandemic)', 'Y', 'Temporary measure — confirm whether still in force'],
  [36, 'Prime Minister decree — COVID-19 measures', 'Decree 3400 / 2021', 'OH&S (pandemic)', 'Y', 'Temporary measure — confirm whether still in force'],
];

const SA_CANDIDATES = [
  ['General Environmental Law and its implementing regulations', 'Royal Decree M/165 (1441H)', 'Environment', 'National Center for Environmental Compliance (NCEC) permits and standards'],
  ['Waste Management Law and implementing regulations', 'Royal Decree M/3 (1443H)', 'Environment (waste)', 'National Center for Waste Management (MWAN) registration and licensed contractors'],
  ['Labor Law (OSH provisions) and MHRSD OSH regulations', 'Royal Decree M/51 (1426H), as amended', 'OH&S', 'Ministry of Human Resources and Social Development'],
  ['Civil Defense Law; Saudi Building Code SBC 801 (fire protection)', 'Royal Decree M/10 (1406H)', 'OH&S (fire)', 'General Directorate of Civil Defense — safety licence, fire systems, drills'],
  ['Social Insurance Law — occupational hazards branch', 'GOSI', 'OH&S (work injury)', 'Work-injury notification to GOSI'],
  ['MODON industrial city regulations (if the plant is in a MODON city)', 'MODON', 'Environment / OH&S', 'Source folder "modon paper" exists — confirm site status'],
];

module.exports = { EG, SA_CANDIDATES };
