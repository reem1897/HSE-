'use strict';
// Requirement catalogue for the clause coverage matrix.
// Requirements are PARAPHRASED (not reproduced) from licensed copies. Do not paste standard text here.
//
// Edition verification (2026-11-01):
//  - ISO 14001:2026, 4th edition, 2026-04: verified against the user-supplied licensed copy
//    (ISO_140012026_ed.4) and certification-body notices. Clause numbering below follows that copy.
//  - ISO 45001:2018 + Amd 1:2024: current edition per certification-body notices (revision expected ~2027).
//    Numbering follows the published 2018 edition. NOTE: the user-supplied file "ISO_45001_2018.pdf"
//    shows pre-publication draft numbering (e.g. 8.2 Management of change, 10.1 Incident...). It was NOT
//    used for numbering; see confirmation item CR-GL-0001.

const EDITIONS = {
  ISO45001: { code: 'ISO45001', label: 'ISO 45001:2018 + Amd 1:2024', short: 'ISO 45001', verified: 'Current edition per certification-body notices (Nov 2026); published numbering used. User copy shows draft numbering — see CR-GL-0001.' },
  ISO14001: { code: 'ISO14001', label: 'ISO 14001:2026 (4th ed.)', short: 'ISO 14001', verified: 'Verified against user-supplied licensed copy, 4th edition 2026-04.' },
};

// [ref, title, paraphrased requirement, applicability]
// applicability: 'R' reference clause (1-3), 'A' applicable requirement
const R45 = [
  ['1', 'Scope', 'Defines what the standard covers: an OH&S management system to provide safe and healthy workplaces, applicable to any organization. Reference only — no auditable requirement.', 'R'],
  ['2', 'Normative references', 'No normative references. Reference only.', 'R'],
  ['3', 'Terms and definitions', 'Defines terms used (worker, hazard, OH&S risk, incident, contractor, etc.). Used as the glossary of the portal. Reference only.', 'R'],
  ['4.1', 'Understanding the organization and its context', 'Determine internal and external issues that affect the ability to achieve the intended OH&S outcomes; Amd 1:2024 requires determining whether climate change is a relevant issue.', 'A'],
  ['4.2', 'Needs and expectations of workers and other interested parties', 'Identify workers and other relevant interested parties, their needs and expectations, and which become legal or other requirements (Amd 1:2024 note: parties may have climate-related requirements).', 'A'],
  ['4.3', 'Determining the scope of the OH&S management system', 'Set and document the boundaries and applicability of the OH&S MS considering issues, requirements and planned or performed work-related activities.', 'A'],
  ['4.4', 'OH&S management system', 'Establish, implement, maintain and continually improve the OH&S MS, including the processes needed and their interactions.', 'A'],
  ['5.1', 'Leadership and commitment', 'Top management takes overall accountability for preventing work-related injury and ill health, provides resources, integrates the system into business processes, protects workers from reprisals and supports safety committees.', 'A'],
  ['5.2', 'OH&S policy', 'Establish a documented, communicated policy with commitments to safe and healthy conditions, legal compliance, eliminating hazards and reducing risks, continual improvement and worker consultation and participation.', 'A'],
  ['5.3', 'Organizational roles, responsibilities and authorities', 'Assign and communicate responsibilities and authorities for relevant roles; workers at each level take responsibility for the OH&S aspects they control.', 'A'],
  ['5.4', 'Consultation and participation of workers', 'Provide mechanisms, time, training and resources for consultation and participation of workers (non-managerial workers especially) and remove obstacles.', 'A'],
  ['6.1.1', 'Actions to address risks and opportunities — general', 'Plan by considering context, requirements and scope to determine risks and opportunities; keep documented information on them and on the planning processes.', 'A'],
  ['6.1.2.1', 'Hazard identification', 'Run an ongoing, proactive process to identify hazards covering routine and non-routine activities, human factors, emergencies, changes, past incidents and people near the workplace.', 'A'],
  ['6.1.2.2', 'Assessment of OH&S risks and other risks to the OH&S MS', 'Assess OH&S risks from identified hazards and other risks to the system using defined, proactive methodologies and criteria, kept as documented information.', 'A'],
  ['6.1.2.3', 'Assessment of OH&S opportunities and other opportunities', 'Assess opportunities to enhance OH&S performance and improve the system, including adapting work to workers and eliminating hazards.', 'A'],
  ['6.1.3', 'Determination of legal requirements and other requirements', 'Determine and have access to applicable legal and other requirements, determine how they apply and what must be communicated, and keep them up to date.', 'A'],
  ['6.1.4', 'Planning action', 'Plan actions for risks, opportunities, legal requirements and emergencies, integrate them into processes and evaluate effectiveness, applying the hierarchy of controls.', 'A'],
  ['6.2.1', 'OH&S objectives', 'Set measurable (where practicable), monitored and communicated OH&S objectives consistent with the policy, considering requirements, risks and consultation results.', 'A'],
  ['6.2.2', 'Planning to achieve OH&S objectives', 'For each objective define what, resources, who, when, how results are evaluated (indicators) and integration into business processes; keep documented information.', 'A'],
  ['7.1', 'Resources', 'Determine and provide the resources needed for the OH&S MS.', 'A'],
  ['7.2', 'Competence', 'Determine competence (including hazard identification ability), ensure it through education, training or experience, act to close gaps and keep evidence.', 'A'],
  ['7.3', 'Awareness', 'Make workers aware of the policy, objectives, their contribution, incidents and investigation results, hazards and risks relevant to them, and their right to remove themselves from imminent danger.', 'A'],
  ['7.4.1', 'Communication — general', 'Establish internal and external communication processes defining what, when, with whom and how, considering diversity aspects (language, culture, literacy).', 'A'],
  ['7.4.2', 'Internal communication', 'Communicate OH&S information among levels and functions, including changes, and enable workers to contribute to improvement.', 'A'],
  ['7.4.3', 'External communication', 'Communicate relevant OH&S information externally as established and as required by legal and other requirements.', 'A'],
  ['7.5.1', 'Documented information — general', 'Include documented information required by the standard and that determined necessary for effectiveness.', 'A'],
  ['7.5.2', 'Creating and updating', 'Ensure identification, format and media, and review and approval of documented information.', 'A'],
  ['7.5.3', 'Control of documented information', 'Control availability, protection, distribution, access, storage, changes, retention and disposition, including external-origin documents.', 'A'],
  ['8.1.1', 'Operational planning and control — general', 'Plan, implement, control and maintain processes with operating criteria, controls in line with criteria, documented information, and adapting work to workers; coordinate at multi-employer workplaces.', 'A'],
  ['8.1.2', 'Eliminating hazards and reducing OH&S risks', 'Apply the hierarchy of controls: elimination, substitution, engineering controls, administrative controls, PPE.', 'A'],
  ['8.1.3', 'Management of change', 'Implement and control planned temporary and permanent changes (new processes, equipment, legal changes, knowledge) and review unintended changes.', 'A'],
  ['8.1.4.1', 'Procurement — general', 'Control procurement of products and services to ensure conformity with the OH&S MS.', 'A'],
  ['8.1.4.2', 'Contractors', 'Coordinate procurement with contractors to identify hazards and control risks from contractor activities, and ensure contractor workers meet OH&S requirements, with selection criteria.', 'A'],
  ['8.1.4.3', 'Outsourcing', 'Ensure outsourced functions and processes are controlled, consistent with legal and other requirements and system outcomes.', 'A'],
  ['8.2', 'Emergency preparedness and response', 'Establish emergency response including first aid, training, periodic testing and exercises, evaluation and revision, communication to workers, contractors, visitors and authorities.', 'A'],
  ['9.1.1', 'Monitoring, measurement, analysis and performance evaluation — general', 'Determine what to monitor (legal compliance, hazards and risks, objectives, controls), methods, criteria, timing; ensure calibrated or verified equipment.', 'A'],
  ['9.1.2', 'Evaluation of compliance', 'Evaluate compliance with legal and other requirements at defined frequency, act if needed, maintain knowledge of compliance status and keep results.', 'A'],
  ['9.2.1', 'Internal audit — general', 'Conduct internal audits at planned intervals to determine conformity and effective implementation.', 'A'],
  ['9.2.2', 'Internal audit programme', 'Plan the audit programme (frequency, methods, responsibilities, consultation, reporting), select objective auditors and report results to workers and representatives.', 'A'],
  ['9.3', 'Management review', 'Top management reviews the system at planned intervals with defined inputs (incidents, consultation, risks, compliance, objectives) and outputs (decisions, actions) and communicates results to workers.', 'A'],
  ['10.1', 'Improvement — general', 'Determine opportunities for improvement and implement actions needed to achieve intended outcomes.', 'A'],
  ['10.2', 'Incident, nonconformity and corrective action', 'Report, investigate and act on incidents and nonconformities in a timely way with worker participation; eliminate root causes, review risk assessments, check effectiveness and keep records.', 'A'],
  ['10.3', 'Continual improvement', 'Continually improve suitability, adequacy and effectiveness by enhancing performance, promoting a supportive culture, worker participation and communicating results.', 'A'],
];

const R14 = [
  ['1', 'Scope', 'Defines the environmental management system requirements for enhancing environmental performance. Reference only.', 'R'],
  ['2', 'Normative references', 'No normative references. Reference only.', 'R'],
  ['3', 'Terms and definitions', 'Defines terms (environmental aspect, compliance obligations, life cycle, etc.). Reference only.', 'R'],
  ['4.1', 'Understanding the organization and its context', 'Determine internal and external issues, explicitly including environmental conditions affecting or affected by the organization such as pollution, resource availability, climate change, biodiversity and ecosystem health.', 'A'],
  ['4.2', 'Needs and expectations of interested parties', 'Determine relevant interested parties, their requirements (including on environmental conditions) and which become compliance obligations.', 'A'],
  ['4.3', 'Determining the scope of the EMS', 'Determine boundaries and applicability considering issues, obligations, units, activities, products, services and life-cycle control and influence; scope is documented and available to interested parties.', 'A'],
  ['4.4', 'Environmental management system', 'Establish, implement, maintain and continually improve the EMS, including processes and interactions, using knowledge from 4.1 and 4.2.', 'A'],
  ['5.1', 'Leadership and commitment', 'Top management is accountable for EMS effectiveness, integrates it into business processes, provides resources and supports other managers.', 'A'],
  ['5.2', 'Environmental policy', 'Policy appropriate to context, framework for objectives, commitment to protect the environment including pollution prevention and context-specific commitments, compliance and continual improvement; documented, communicated and available.', 'A'],
  ['5.3', 'Roles, responsibilities and authorities', 'Assign and communicate responsibility and authority for EMS conformity and reporting EMS and environmental performance to top management.', 'A'],
  ['6.1.1', 'Actions to address risks and opportunities — general', 'Establish the processes needed for 6.1.2 to 6.1.5 and document them to the extent needed for confidence.', 'A'],
  ['6.1.2', 'Environmental aspects', 'Determine aspects and impacts of activities, products and services with a life-cycle perspective, under normal, abnormal, change and emergency conditions; determine significance by criteria and communicate significant aspects.', 'A'],
  ['6.1.3', 'Compliance obligations', 'Determine, access and apply compliance obligations related to environmental aspects and keep them as documented information.', 'A'],
  ['6.1.4', 'Risks and opportunities', 'Considering context, interested parties and scope, determine risks and opportunities related to aspects, obligations and other issues that need to be addressed, including the effect of external environmental conditions; document them.', 'A'],
  ['6.1.5', 'Planning action', 'Plan actions for significant aspects, obligations, and risks and opportunities, integrate them into processes and plan how effectiveness is evaluated.', 'A'],
  ['6.2.1', 'Environmental objectives', 'Set objectives at relevant functions and levels considering significant aspects, obligations and risks; consistent, measurable, monitored, communicated, updated and documented.', 'A'],
  ['6.2.2', 'Planning actions to achieve environmental objectives', 'Determine what, resources, who, when and how results are evaluated with indicators; consider integration with business processes.', 'A'],
  ['6.3', 'Planning of changes', 'Carry out changes to the EMS in a planned and managed way so intended outcomes can still be achieved. (New explicit clause in the 2026 edition.)', 'A'],
  ['7.1', 'Resources', 'Determine and provide resources for the EMS.', 'A'],
  ['7.2', 'Competence', 'Determine competence for work affecting environmental performance and compliance, ensure it, determine training needs, act and evaluate effectiveness; keep evidence.', 'A'],
  ['7.3', 'Awareness', 'Ensure awareness of the policy, significant aspects related to the person\'s work, their contribution and implications of nonconformity.', 'A'],
  ['7.4.1', 'Communication — general', 'Establish communication processes (what, when, with whom, how), consider compliance obligations, ensure reliable information and respond to relevant communications; keep evidence.', 'A'],
  ['7.4.2', 'Internal communication', 'Communicate EMS information internally including changes and enable workers to contribute to improvement.', 'A'],
  ['7.4.3', 'External communication', 'Communicate externally as established and as required by compliance obligations.', 'A'],
  ['7.5.1', 'Documented information — general', 'Include documented information required by the standard and determined necessary.', 'A'],
  ['7.5.2', 'Creating and updating documented information', 'Ensure identification, format and media, and review and approval.', 'A'],
  ['7.5.3', 'Control of documented information', 'Control availability, protection, distribution, storage, version control, retention, and external-origin documents.', 'A'],
  ['8.1', 'Operational planning and control', 'Establish operating criteria and controls (hierarchy noted), control planned changes and unintended changes, control or influence externally provided processes, and apply life-cycle controls for design, procurement, provider communication and product information.', 'A'],
  ['8.2', 'Emergency preparedness and response', 'Prepare for and respond to potential emergencies identified in 6.1.2, mitigate impacts, periodically test and review response, and provide information and training to relevant parties.', 'A'],
  ['9.1.1', 'Monitoring, measurement, analysis and evaluation — general', 'Evaluate environmental performance: determine what, methods, criteria and indicators, when; use calibrated or verified equipment; communicate performance; keep evidence.', 'A'],
  ['9.1.2', 'Evaluation of compliance', 'Evaluate fulfilment of compliance obligations at a defined frequency, act as needed and maintain knowledge of compliance status; keep evidence.', 'A'],
  ['9.2.1', 'Internal audit — general', 'Conduct internal audits at planned intervals for conformity and effective implementation.', 'A'],
  ['9.2.2', 'Internal audit programme', 'Establish audit programmes considering environmental importance, changes and previous results; define objectives, criteria, scope; ensure objectivity; report results; keep evidence.', 'A'],
  ['9.3.1', 'Management review — general', 'Top management reviews the EMS at planned intervals for suitability, adequacy and effectiveness.', 'A'],
  ['9.3.2', 'Management review inputs', 'Inputs include previous actions, changes in issues, obligations, significant aspects and risks, objective achievement, performance trends, resources, communications and complaints, and improvement opportunities.', 'A'],
  ['9.3.3', 'Management review results', 'Outputs include conclusions on suitability, decisions on improvement and changes, actions where objectives are missed, integration opportunities and strategic implications; documented.', 'A'],
  ['10.1', 'Continual improvement', 'Continually improve the EMS to enhance environmental performance by determining and acting on improvement opportunities.', 'A'],
  ['10.2', 'Nonconformity and corrective action', 'React to nonconformities, deal with consequences including environmental impacts, determine causes, implement and review corrective action, update the EMS if necessary; keep evidence.', 'A'],
];

function requirements() {
  const out = [];
  for (const [ref, title, para, app] of R45) out.push({ id: `ISO45001:${ref}`, standard: 'ISO45001', ref, title, paraphrase: para, applicability: app });
  for (const [ref, title, para, app] of R14) out.push({ id: `ISO14001:${ref}`, standard: 'ISO14001', ref, title, paraphrase: para, applicability: app });
  return out;
}

module.exports = { EDITIONS, requirements };
