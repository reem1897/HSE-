# Deploying the portal on Vercel + Supabase / النشر على Vercel مع Supabase

The database is ready: Supabase project **sedco-ihse** (ref `nolicxiptirojfwwuafr`, region eu-central-1 Frankfurt). The schema is already applied and row-level security blocks Supabase's public API. You only need a connection string and the Vercel project.

قاعدة البيانات جاهزة على Supabase (مشروع sedco-ihse في فرانكفورت) والجداول منشأة ومحمية. المطلوب فقط: رابط الاتصال، ثم مشروع Vercel.

## 1. Get the database connection string (Supabase) / رابط الاتصال

1. Open https://supabase.com/dashboard/project/nolicxiptirojfwwuafr.
2. Go to **Project Settings → Database → Reset database password**. Choose a strong password and keep it safe.
3. Click **Connect** (top of the page), open **Transaction pooler** (port **6543**), and copy the URI. It looks like:
   `postgresql://postgres.nolicxiptirojfwwuafr:<PASSWORD>@aws-0-eu-central-1.pooler.supabase.com:6543/postgres`
4. Replace `<PASSWORD>` with the password from step 2. If the password contains `@ : / ? #`, URL-encode those characters.

## 2. Create the Vercel project / إنشاء مشروع Vercel

**Option A — GitHub (recommended):**
1. Create a **private** GitHub repository and upload the contents of the `sedco-ihse-portal` folder. Do not upload `node_modules`, `data`, `deliverables` or `backups`; `.gitignore` already excludes them.
2. In Vercel, go to **Add New → Project**, import the repository, and leave the framework preset as **Other**.

**Option B — Vercel CLI from your computer** (inside the `sedco-ihse-portal` folder):

```bash
npx vercel
```

## 3. Environment variables (Vercel → Settings → Environment Variables) / متغيرات البيئة

| Name | Value |
|---|---|
| `DATABASE_URL` | the Transaction-pooler URI from step 1 |
| `IHSE_ADMIN_PASSWORD` | the first administrator password (10+ characters). It is used only when the database has no users yet. |

Then deploy. With the CLI:

```bash
npx vercel --prod
```

Never put these values in the code or commit them to GitHub.

## 4. First start / أول تشغيل

The first request creates the content: 236 documents, about 100 Word/Excel files and 59 confirmation items. This takes about 20–40 seconds, so the first page load is slow. It runs as one transaction, so if it times out nothing is half-written and the next request simply retries.

To seed from your computer instead (faster and more predictable):

```bash
DATABASE_URL="postgresql://..." IHSE_ADMIN_PASSWORD="..." npm run seed
```

Sign in as **admin** with `IHSE_ADMIN_PASSWORD`, change the password under **Change password**, then create the real users (Administration → Users).

## 5. What differs on Vercel / الفروق على Vercel

- **Uploads** are limited to **4 MB per file** (a Vercel platform limit). Larger files should stay in SharePoint and be registered as a link.
- **PDF preview/conversion is off.** Vercel has no LibreOffice. Word/Excel download, image and PDF preview, and ZIP export all work.
- **Backups:**
  - The Supabase free plan has no automatic backups. Run this regularly from a computer:

    ```bash
    DATABASE_URL="..." npm run backup
    ```

  - Or upgrade the Supabase plan.
  - To restore into a new, empty project:

    ```bash
    npm run restore -- <file>
    ```

- **Database size:** the free Supabase database is 500 MB. Stored files count towards that, and the initial content is about 5 MB.

## Local development

Without `DATABASE_URL` the portal uses an embedded Postgres (PGlite) in `./data/pg`, with identical SQL.

```bash
npm ci
```

```bash
npm start
```

Run the tests:

```bash
npm test
```
